# 部署到 Render 指南

## 📋 部署前准备

### 1. 注册账号
- 访问 https://render.com
- 点击 "Get Started for Free"
- 使用 GitHub 账号登录（推荐）

### 2. 创建 GitHub 仓库
- 访问 https://github.com/new
- Repository name: `star-sign-app`（或其他名称）
- 选择 Public（公开）
- **不要** 勾选 "Initialize this repository with a README"
- 点击 "Create repository"

---

## 📦 上传代码到 GitHub

### 方法：使用 GitHub 网页上传

1. **下载并安装 Git**
   - 访问 https://git-scm.com/download/win
   - 下载并安装

2. **打开命令行，进入项目目录**
   ```bash
   cd d:\xiangmu\Star
   ```

3. **初始化 Git 仓库**
   ```bash
   git init
   ```

4. **添加所有文件**
   ```bash
   git add .
   ```

5. **提交代码**
   ```bash
   git commit -m "Initial commit"
   ```

6. **连接 GitHub 仓库**
   ```bash
   git remote add origin https://github.com/你的用户名/star-sign-app.git
   ```

7. **推送代码**
   ```bash
   git push -u origin main
   ```
   或
   ```bash
   git push -u origin master
   ```

---

## 🚀 部署到 Render

### 步骤 1：创建 Web Service

1. 访问 https://dashboard.render.com
2. 点击 **New +** 按钮
3. 选择 **Web Service**

### 步骤 2：选择仓库

1. 在 "Connect a repository" 中找到你的 `star-sign-app` 仓库
2. 点击 **Connect**

### 步骤 3：配置服务

填写以下信息：

| 配置项 | 值 |
|--------|-----|
| **Name** | `star-sign-app`（或你喜欢的名字） |
| **Environment** | `Python 3` |
| **Region** | `Singapore`（亚洲）或 `Oregon`（美国） |
| **Branch** | `main` 或 `master` |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `gunicorn app:app` |
| **Plan** | `Free`（免费版） |

### 步骤 4：高级设置（可选）

点击 **Advanced** 按钮：
- **Auto-Deploy**: 选择 `Yes`（代码更新自动部署）

### 步骤 5：创建服务

点击 **Create Web Service**

---

## ⏳ 等待部署

- 部署过程大约需要 **2-5 分钟**
- 你可以在页面上看到构建日志
- 当出现 `Your service is live` 时，部署完成！

---

## 🌐 访问你的应用

部署完成后，Render 会给你一个网址：
```
https://star-sign-app.onrender.com
```

把这个链接分享给朋友，他们就能访问了！

---

## 🔄 后续更新代码

如果你修改了代码，需要重新部署：

```bash
cd d:\xiangmu\Star
git add .
git commit -m "更新说明"
git push
```

Render 会自动重新部署（因为设置了 Auto-Deploy）

---

## ❗ 常见问题

### 1. 构建失败
检查 `requirements.txt` 是否包含所有依赖

### 2. 应用无法启动
检查 `Procfile` 内容是否正确：
```
web: gunicorn app:app
```

### 3. 免费版的限制
- 15分钟无访问会自动休眠
- 首次访问需要等待唤醒（约30秒）
- 每月750小时免费额度

---

## 📱 分享给朋友

部署完成后，你可以：
1. 把链接发给朋友
2. 生成二维码方便手机扫描
3. 分享到社交媒体

**示例链接：**
```
https://star-sign-app.onrender.com
```

---

## 🎉 完成！

你的星座契合度与MBTI分析应用现在可以在互联网上访问了！

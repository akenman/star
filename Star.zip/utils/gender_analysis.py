"""
性别差异分析模块
根据性别调整星座+MBTI的分析结果
"""

def apply_gender_differences(base_analysis, gender):
    """
    根据性别调整分析结果
    """
    if gender not in ['male', 'female']:
        return base_analysis
    
    analysis = base_analysis.copy()
    
    # 调整恋爱风格
    analysis['love_style'] = adjust_love_style_by_gender(
        analysis['love_style'], 
        gender,
        analysis['zodiac']['element'],
        analysis['mbti']['id']
    )
    
    # 调整情感需求
    analysis['emotional_needs'] = adjust_emotional_needs_by_gender(
        analysis['emotional_needs'],
        gender,
        analysis['zodiac']['element']
    )
    
    # 调整恋爱优势
    analysis['love_strengths'] = adjust_strengths_by_gender(
        analysis['love_strengths'],
        gender
    )
    
    # 调整恋爱挑战
    analysis['love_challenges'] = adjust_challenges_by_gender(
        analysis['love_challenges'],
        gender
    )
    
    # 调整理想伴侣特征
    analysis['ideal_partner'] = adjust_ideal_partner_by_gender(
        analysis['ideal_partner'],
        gender
    )
    
    # 调整沟通风格
    analysis['communication_style'] = adjust_communication_by_gender(
        analysis['communication_style'],
        gender
    )
    
    # 调整亲密关系模式
    analysis['intimacy_patterns'] = adjust_intimacy_by_gender(
        analysis['intimacy_patterns'],
        gender
    )
    
    # 添加性别特定的建议
    analysis['gender_specific_advice'] = get_gender_specific_advice(
        gender,
        analysis['zodiac']['element'],
        analysis['mbti']['id']
    )
    
    return analysis


def adjust_love_style_by_gender(love_style, gender, element, mbti_id):
    """根据性别调整恋爱风格"""
    adjusted = love_style.copy()
    
    if gender == 'male':
        # 男性特质调整
        if element == '火象':
            adjusted.append('作为男性，你可能更倾向于主动追求，展现保护欲和领导力')
        elif element == '水象':
            adjusted.append('作为男性，你可能外表坚强但内心敏感，需要学会适当表达脆弱')
        elif element == '土象':
            adjusted.append('作为男性，你可能更注重实际付出，用行动证明爱意')
        elif element == '风象':
            adjusted.append('作为男性，你可能更看重思想交流和智力刺激')
            
        if 'F' in mbti_id:
            adjusted.append('你是感性型男性，可能比典型男性更细腻体贴')
        elif 'T' in mbti_id:
            adjusted.append('你是理性型男性，倾向于用逻辑处理感情问题')
            
    else:  # female
        # 女性特质调整
        if element == '火象':
            adjusted.append('作为女性，你可能热情主动，不拘泥于传统女性角色')
        elif element == '水象':
            adjusted.append('作为女性，你情感丰富细腻，直觉敏锐，重视情感连接')
        elif element == '土象':
            adjusted.append('作为女性，你务实稳重，重视安全感和稳定的关系')
        elif element == '风象':
            adjusted.append('作为女性，你独立自主，重视精神层面的契合')
            
        if 'T' in mbti_id:
            adjusted.append('你是理性型女性，可能比典型女性更独立客观')
        elif 'F' in mbti_id:
            adjusted.append('你是感性型女性，情感表达丰富，善于照顾他人')
    
    return adjusted


def adjust_emotional_needs_by_gender(emotional_needs, gender, element):
    """根据性别调整情感需求"""
    adjusted = emotional_needs.copy()
    
    if gender == 'male':
        # 男性常见需求
        male_needs = ['被尊重', '被信任', '个人空间']
        if element == '水象':
            male_needs.append('情感安全感')
        elif element == '火象':
            male_needs.append('被崇拜')
        
        adjusted['primary_needs'] = list(dict.fromkeys(
            adjusted['primary_needs'] + male_needs
        ))[:5]
        
        # 男性底线
        male_deal_breakers = ['被轻视', '过度控制', '不信任']
        adjusted['deal_breakers'] = list(dict.fromkeys(
            adjusted['deal_breakers'] + male_deal_breakers
        ))[:4]
        
    else:  # female
        # 女性常见需求
        female_needs = ['被呵护', '情感关注', '安全感']
        if element == '风象':
            female_needs.append('思想共鸣')
        elif element == '土象':
            female_needs.append('稳定承诺')
        
        adjusted['primary_needs'] = list(dict.fromkeys(
            adjusted['primary_needs'] + female_needs
        ))[:5]
        
        # 女性底线
        female_deal_breakers = ['被忽视', '不忠诚', '情感冷漠']
        adjusted['deal_breakers'] = list(dict.fromkeys(
            adjusted['deal_breakers'] + female_deal_breakers
        ))[:4]
    
    return adjusted


def adjust_strengths_by_gender(strengths, gender):
    """根据性别调整优势"""
    adjusted = strengths.copy()
    
    if gender == 'male':
        male_strengths = [
            '在关系中愿意承担责任',
            '面对困难时表现出坚强',
            '愿意保护和支持伴侣'
        ]
    else:
        male_strengths = [
            '善于营造温馨的关系氛围',
            '能够敏锐察觉伴侣情绪',
            '在细节中表达关爱'
        ]
    
    return adjusted + male_strengths[:2]


def adjust_challenges_by_gender(challenges, gender):
    """根据性别调整挑战"""
    adjusted = challenges.copy()
    
    if gender == 'male':
        male_challenges = [
            '社会期待可能让你压抑真实情感',
            '可能过于理性而忽视伴侣情感需求',
            '需要学会表达脆弱和依赖'
        ]
    else:
        male_challenges = [
            '可能过于在意关系而忽略自我',
            '情感敏感度高容易受伤',
            '需要保持独立性和自我价值'
        ]
    
    return adjusted + male_challenges[:2]


def adjust_ideal_partner_by_gender(ideal_partner, gender):
    """根据性别调整理想伴侣特征"""
    adjusted = ideal_partner.copy()
    
    if gender == 'male':
        adjusted['personality_traits'].extend([
            '温柔体贴' if 'F' not in ideal_partner.get('mbti', '') else '理性独立',
            '善解人意'
        ])
        adjusted['love_style'] += '，能够理解并支持你的事业和追求'
    else:
        adjusted['personality_traits'].extend([
            '成熟稳重' if 'T' not in ideal_partner.get('mbti', '') else '感性浪漫',
            '细心体贴'
        ])
        adjusted['love_style'] += '，能够给予你足够的情感关注和安全感'
    
    adjusted['personality_traits'] = list(dict.fromkeys(adjusted['personality_traits']))[:5]
    
    return adjusted


def adjust_communication_by_gender(communication_style, gender):
    """根据性别调整沟通风格"""
    adjusted = communication_style.copy()
    
    if gender == 'male':
        adjusted['expression_way'] += '。作为男性，你可能更倾向于直接解决问题，而非单纯倾听'
        adjusted['conflict_communication'] += '。你可能需要学会更多地表达情感，而非只关注事实'
    else:
        adjusted['expression_way'] += '。作为女性，你可能更注重情感交流和细节分享'
        adjusted['conflict_communication'] += '。你可能需要学会更直接地表达需求，而非期待对方猜测'
    
    return adjusted


def adjust_intimacy_by_gender(intimacy_patterns, gender):
    """根据性别调整亲密关系模式"""
    adjusted = intimacy_patterns.copy()
    
    if gender == 'male':
        adjusted['closeness_need'] += '。男性身份可能让你在表达亲密时有所保留，需要安全感才能敞开心扉'
        adjusted['vulnerability'] += '。社会期待可能让你更难展现脆弱，但这是建立深度连接的关键'
    else:
        adjusted['closeness_need'] += '。你可能更渴望情感上的融合和深度的精神连接'
        adjusted['vulnerability'] += '。你可能更容易表达情感，但需要确保对方能够珍惜这份信任'
    
    return adjusted


def get_gender_specific_advice(gender, element, mbti_id):
    """获取性别特定建议"""
    advice = []
    
    if gender == 'male':
        advice.append('学会表达情感：社会期待男性坚强，但适度表达脆弱能让关系更亲密')
        advice.append('倾听先于解决：当伴侣分享问题时，先倾听理解，不要急于提供解决方案')
        
        if element == '火象':
            advice.append('控制主导欲：热情主动是优点，但也要给伴侣决策空间')
        elif element == '水象':
            advice.append('建立自信：敏感细腻不是弱点，学会欣赏自己的情感深度')
        elif element == '土象':
            advice.append('增加浪漫：实际行动很重要，但偶尔的浪漫惊喜能让关系保鲜')
        elif element == '风象':
            advice.append('情感投入：思想交流很精彩，但也要投入真实的情感')
            
        if 'T' in mbti_id:
            advice.append('关注情感：理性分析很重要，但伴侣的情感需求同样值得重视')
        elif 'F' in mbti_id:
            advice.append('保持独立：感性体贴是优势，但不要过度依赖伴侣的认可')
            
    else:  # female
        advice.append('保持独立：在投入关系的同时，保持自己的兴趣、朋友和事业')
        advice.append('直接表达：期待对方猜测你的想法容易造成误会，学会直接表达需求')
        
        if element == '火象':
            advice.append('适度温柔：独立主动很迷人，但偶尔的温柔能让伴侣感到被需要')
        elif element == '水象':
            advice.append('建立界限：敏感体贴是优点，但不要过度牺牲自己的需求')
        elif element == '土象':
            advice.append('放松控制：追求完美很好，但接受不完美能让关系更轻松')
        elif element == '风象':
            advice.append('情感投入：独立自由很重要，但深度的情感连接能让关系更稳固')
            
        if 'F' in mbti_id:
            advice.append('理性思考：感性丰富是天赋，但重大决定时也要理性分析')
        elif 'T' in mbti_id:
            advice.append('接纳情感：理性独立很好，但也要允许自己体验和表达情感')
    
    return advice


def get_compatibility_by_gender(zodiac1, mbti1, gender1, zodiac2, mbti2, gender2):
    """
    根据性别组合调整契合度分析
    """
    analysis = {
        'gender_dynamics': '',
        'male_perspective': '',
        'female_perspective': '',
        'relationship_dynamics': []
    }
    
    # 性别动态分析
    if gender1 == 'male' and gender2 == 'female':
        analysis['gender_dynamics'] = '传统男女组合，可能更容易符合社会期待，但也需要注意性别角色不固化'
        analysis['male_perspective'] = '作为男方，你需要在保护欲和尊重对方独立性之间找到平衡'
        analysis['female_perspective'] = '作为女方，你可以在依赖和独立之间自由切换，找到舒适的相处模式'
    elif gender1 == 'female' and gender2 == 'male':
        analysis['gender_dynamics'] = '女男组合，可能打破一些传统模式，创造独特的相处方式'
        analysis['male_perspective'] = '作为男方，你可能需要适应女方更主动或独立的风格'
        analysis['female_perspective'] = '作为女方，你可以主动追求自己想要的，同时给对方发挥空间'
    else:
        analysis['gender_dynamics'] = '同性组合，可能更容易理解彼此，但也需要注意保持新鲜感和独立性'
        analysis['male_perspective'] = '你们可能面临一些社会压力，但也能建立更平等自由的关系'
        analysis['female_perspective'] = '你们可能更容易建立深度情感连接，互相理解和支持'
    
    # 关系动态
    element1 = zodiac1['element']
    element2 = zodiac2['element']
    
    if element1 == element2:
        analysis['relationship_dynamics'].append('相同元素让你们有相似的情感需求，容易产生共鸣')
    
    if 'T' in mbti1['id'] and 'F' in mbti2['id']:
        analysis['relationship_dynamics'].append('理性与感性的组合，可以互补但需要互相理解')
    elif 'F' in mbti1['id'] and 'T' in mbti2['id']:
        analysis['relationship_dynamics'].append('感性与理性的组合，情感与逻辑的平衡')
    
    return analysis

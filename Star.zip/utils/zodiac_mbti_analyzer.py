import random
import hashlib
from datetime import datetime
from data.zodiac_data import get_zodiac_by_id
from data.mbti_data import get_mbti_by_id
from utils.gender_analysis import apply_gender_differences, get_compatibility_by_gender

def generate_combination_analysis(zodiac_id, mbti_id, gender=None):
    """
    生成星座与MBTI的组合分析
    基于星座和MBTI的特征，生成独特的性格分析
    """
    zodiac = get_zodiac_by_id(zodiac_id)
    mbti = get_mbti_by_id(mbti_id)
    
    if not zodiac or not mbti:
        return None
    
    # 生成组合ID
    combination_id = f"{zodiac_id}_{mbti_id}"
    
    # 基于组合ID生成稳定的随机种子
    seed = int(hashlib.md5(combination_id.encode()).hexdigest(), 16)
    random.seed(seed)
    
    # 组合分析
    analysis = {
        "combination_id": combination_id,
        "zodiac": zodiac,
        "mbti": mbti,
        "title": f"{zodiac['name']} + {mbti['id']} ({mbti['name']})",
        
        # 核心性格特征（融合星座和MBTI）
        "core_traits": generate_core_traits(zodiac, mbti),
        
        # 情感特征
        "emotional_traits": generate_emotional_traits(zodiac, mbti),
        
        # 恋爱风格
        "love_style": generate_love_style(zodiac, mbti),
        
        # 恋爱中的优势
        "love_strengths": generate_love_strengths(zodiac, mbti),
        
        # 恋爱中的挑战
        "love_challenges": generate_love_challenges(zodiac, mbti),
        
        # 理想伴侣特征
        "ideal_partner": generate_ideal_partner(zodiac, mbti),
        
        # 恋爱建议
        "love_advice": generate_love_advice(zodiac, mbti),
        
        # 沟通风格
        "communication_style": generate_communication_style(zodiac, mbti),
        
        # 冲突处理方式
        "conflict_style": generate_conflict_style(zodiac, mbti),
        
        # 情感需求
        "emotional_needs": generate_emotional_needs(zodiac, mbti),
        
        # 亲密关系中的行为模式
        "intimacy_patterns": generate_intimacy_patterns(zodiac, mbti),
        
        # 长期关系潜力
        "long_term_potential": generate_long_term_potential(zodiac, mbti),
        
        # 最佳匹配建议
        "best_matches": generate_best_matches(zodiac, mbti),
        
        # 需要避免的匹配
        "challenging_matches": generate_challenging_matches(zodiac, mbti),
        
        # 成长建议
        "growth_areas": generate_growth_areas(zodiac, mbti)
    }
    
    # 重置随机种子
    random.seed()
    
    # 如果提供了性别，应用性别差异调整
    if gender:
        analysis = apply_gender_differences(analysis, gender)
        analysis['gender'] = gender
    
    return analysis


def generate_core_traits(zodiac, mbti):
    """生成核心性格特征"""
    zodiac_traits = zodiac['traits']['personality']
    mbti_traits = mbti['traits']
    
    # 融合特征
    combined = []
    
    # 根据星座元素和MBTI维度生成独特特征
    element = zodiac['element']
    mbti_id = mbti['id']
    
    # 火象星座 + 外向型
    if element == '火象' and 'E' in mbti_id:
        combined.extend(['热情奔放', '充满活力', '领导魅力'])
    # 火象星座 + 内向型
    elif element == '火象' and 'I' in mbti_id:
        combined.extend(['内敛热情', '专注执着', '深沉有力'])
    # 水象星座 + 情感型
    elif element == '水象' and 'F' in mbti_id:
        combined.extend(['情感丰富', '直觉敏锐', '温柔体贴'])
    # 水象星座 + 思考型
    elif element == '水象' and 'T' in mbti_id:
        combined.extend(['理性敏感', '深度思考', '情感控制'])
    # 风象星座 + 直觉型
    elif element == '风象' and 'N' in mbti_id:
        combined.extend(['思维活跃', '创意无限', '理想主义'])
    # 风象星座 + 感觉型
    elif element == '风象' and 'S' in mbti_id:
        combined.extend(['实际灵活', '社交能手', '理性务实'])
    # 土象星座 + 判断型
    elif element == '土象' and 'J' in mbti_id:
        combined.extend(['稳重可靠', '有条不紊', '目标明确'])
    # 土象星座 + 感知型
    elif element == '土象' and 'P' in mbti_id:
        combined.extend(['随性自然', '灵活务实', '享受生活'])
    
    # 添加一些随机组合特征
    all_traits = zodiac_traits + mbti_traits
    random.shuffle(all_traits)
    combined.extend(all_traits[:3])
    
    return list(dict.fromkeys(combined))  # 去重


def generate_emotional_traits(zodiac, mbti):
    """生成情感特征"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    traits = {
        'emotional_depth': '',
        'emotional_expression': '',
        'emotional_stability': '',
        'empathy_level': ''
    }
    
    # 情感深度
    if element == '水象' or 'F' in mbti_id:
        traits['emotional_depth'] = '情感深邃，内心世界丰富'
    elif element == '火象' or 'T' in mbti_id:
        traits['emotional_depth'] = '情感直接，表达明确'
    elif element == '土象':
        traits['emotional_depth'] = '情感稳重，需要时间建立信任'
    else:
        traits['emotional_depth'] = '情感理性，善于分析感受'
    
    # 情感表达方式
    if 'E' in mbti_id and element in ['火象', '风象']:
        traits['emotional_expression'] = '热情外放，喜欢分享感受'
    elif 'I' in mbti_id and element in ['水象', '土象']:
        traits['emotional_expression'] = '内敛含蓄，用行动表达'
    elif 'F' in mbti_id:
        traits['emotional_expression'] = '温柔体贴，善于倾听'
    else:
        traits['emotional_expression'] = '理性分析，客观表达'
    
    # 情感稳定性
    if element == '土象' or 'J' in mbti_id:
        traits['emotional_stability'] = '情绪稳定，不易波动'
    elif element == '水象' or 'P' in mbti_id:
        traits['emotional_stability'] = '情绪敏感，容易受影响'
    elif element == '火象':
        traits['emotional_stability'] = '情绪热烈，来得快去得快'
    else:
        traits['emotional_stability'] = '情绪多变，适应力强'
    
    # 共情能力
    if 'F' in mbti_id or element == '水象':
        traits['empathy_level'] = '共情力强，能深刻理解他人'
    elif 'T' in mbti_id:
        traits['empathy_level'] = '理性理解，提供解决方案'
    else:
        traits['empathy_level'] = '适度共情，保持客观'
    
    return traits


def generate_love_style(zodiac, mbti):
    """生成恋爱风格"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    styles = []
    
    # 追求方式
    if 'E' in mbti_id and element == '火象':
        styles.append('主动热情，直接表白，喜欢追求的刺激感')
    elif 'I' in mbti_id and element == '水象':
        styles.append('默默关注，用细节表达好感，等待对方察觉')
    elif 'E' in mbti_id:
        styles.append('社交场合展现魅力，通过互动建立连接')
    else:
        styles.append('谨慎观察，深思熟虑后才会行动')
    
    # 恋爱节奏
    if element == '火象' or 'P' in mbti_id:
        styles.append('喜欢快节奏的恋爱，追求新鲜感和激情')
    elif element == '土象' or 'J' in mbti_id:
        styles.append('慢热型，需要时间建立信任和安全感')
    elif element == '水象':
        styles.append('情感深入型，一旦投入就会全心全意')
    else:
        styles.append('灵活多变，根据感觉调整节奏')
    
    # 表达爱意
    zodiac_love = zodiac['traits']['love']
    mbti_love = mbti['love_style']
    styles.append(f"结合{zodiac['name']}的{zodiac_love[0]}特质和{mbti['name']}的{mbti_love}")
    
    return styles


def generate_love_strengths(zodiac, mbti):
    """生成恋爱中的优势"""
    strengths = []
    
    # 星座优势
    zodiac_strengths = zodiac['traits']['strengths']
    strengths.extend([
        f"拥有{zodiac['name']}的{strength}" for strength in zodiac_strengths[:2]
    ])
    
    # MBTI优势
    mbti_strengths = mbti['strengths']
    strengths.extend([
        f"具备{mbti['name']}的{strength}" for strength in mbti_strengths[:2]
    ])
    
    # 组合优势
    element = zodiac['element']
    mbti_id = mbti['id']
    
    if element == '火象' and 'E' in mbti_id:
        strengths.append('能够点燃恋爱的激情，让关系充满活力')
    elif element == '水象' and 'F' in mbti_id:
        strengths.append('情感细腻，能给予伴侣深度的情感支持')
    elif element == '风象' and 'N' in mbti_id:
        strengths.append('思维活跃，能为关系带来新鲜感和创意')
    elif element == '土象' and 'J' in mbti_id:
        strengths.append('踏实可靠，能给伴侣安全感和稳定感')
    
    if 'T' in mbti_id:
        strengths.append('理性分析问题，能有效解决关系中的困难')
    if 'F' in mbti_id:
        strengths.append('情感共鸣强，能建立深度的情感连接')
    
    return strengths[:5]


def generate_love_challenges(zodiac, mbti):
    """生成恋爱中的挑战"""
    challenges = []
    
    # 星座挑战
    zodiac_problems = zodiac['love_problems']
    challenges.extend(zodiac_problems[:2])
    
    # MBTI挑战
    mbti_challenges = mbti['love_challenges']
    challenges.extend(mbti_challenges[:2])
    
    # 组合挑战
    element = zodiac['element']
    mbti_id = mbti['id']
    
    if element == '火象' and 'T' in mbti_id:
        challenges.append('可能过于直接，忽视伴侣的情感需求')
    elif element == '水象' and 'I' in mbti_id:
        challenges.append('可能过于敏感，容易陷入情绪低谷')
    elif element == '风象' and 'P' in mbti_id:
        challenges.append('可能缺乏稳定性，让伴侣感到不安')
    elif element == '土象' and 'J' in mbti_id:
        challenges.append('可能过于固执，难以妥协和变通')
    
    return challenges[:5]


def generate_ideal_partner(zodiac, mbti):
    """生成理想伴侣特征"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    ideal = {
        'personality_traits': [],
        'love_style': '',
        'values': [],
        'deal_breakers': []
    }
    
    # 性格特质
    if element == '火象':
        ideal['personality_traits'].extend(['热情', '独立', '有活力'])
    elif element == '水象':
        ideal['personality_traits'].extend(['温柔', '体贴', '情感丰富'])
    elif element == '风象':
        ideal['personality_traits'].extend(['聪明', '幽默', '开放'])
    elif element == '土象':
        ideal['personality_traits'].extend(['稳重', '可靠', '务实'])
    
    if 'E' in mbti_id:
        ideal['personality_traits'].append('外向善交际')
    else:
        ideal['personality_traits'].append('内敛深沉')
    
    if 'F' in mbti_id:
        ideal['personality_traits'].append('情感细腻')
    else:
        ideal['personality_traits'].append('理性客观')
    
    # 恋爱风格
    if 'J' in mbti_id:
        ideal['love_style'] = '认真负责，有规划，重视承诺'
    else:
        ideal['love_style'] = '随性自然，灵活多变，享受当下'
    
    # 价值观
    ideal['values'] = mbti['love_needs'][:3]
    
    # 不能接受的
    if element == '火象':
        ideal['deal_breakers'].extend(['冷漠', '控制欲过强', '缺乏激情'])
    elif element == '水象':
        ideal['deal_breakers'].extend(['不忠诚', '情感疏离', '忽视感受'])
    elif element == '风象':
        ideal['deal_breakers'].extend(['无趣', '思想封闭', '过度依赖'])
    elif element == '土象':
        ideal['deal_breakers'].extend(['不负责任', '不稳定', '不诚实'])
    
    return ideal


def generate_love_advice(zodiac, mbti):
    """生成恋爱建议"""
    advice = []
    
    element = zodiac['element']
    mbti_id = mbti['id']
    
    # 基于星座的建议
    if element == '火象':
        advice.append('学会控制冲动，给关系一些沉淀的时间')
        advice.append('在热情之余，也要关注伴侣的实际需求')
    elif element == '水象':
        advice.append('不要过度敏感，学会信任伴侣')
        advice.append('表达情感时也要考虑对方的接受能力')
    elif element == '风象':
        advice.append('在追求自由的同时，也要给伴侣安全感')
        advice.append('深入交流比广泛社交更能建立深度连接')
    elif element == '土象':
        advice.append('适当放松，不要对关系有过高的完美要求')
        advice.append('学会表达情感，而不仅仅是用行动证明')
    
    # 基于MBTI的建议
    if 'I' in mbti_id:
        advice.append('主动与伴侣分享内心想法，不要完全封闭自己')
    if 'E' in mbti_id:
        advice.append('给伴侣独处的时间，尊重对方的个人空间')
    if 'T' in mbti_id:
        advice.append('多关注伴侣的情感需求，而不是只给解决方案')
    if 'F' in mbti_id:
        advice.append('保持理性，不要因为情绪波动做出冲动决定')
    if 'J' in mbti_id:
        advice.append('学会灵活变通，不要对关系有太多固定期待')
    if 'P' in mbti_id:
        advice.append('建立一些共同的目标和规划，增加关系稳定性')
    
    return advice[:5]


def generate_communication_style(zodiac, mbti):
    """生成沟通风格"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    style = {
        'expression_way': '',
        'listening_style': '',
        'conflict_communication': '',
        'intimacy_communication': ''
    }
    
    # 表达方式
    if 'E' in mbti_id and element in ['火象', '风象']:
        style['expression_way'] = '直接表达，喜欢讨论和分享想法'
    elif 'I' in mbti_id and element in ['水象', '土象']:
        style['expression_way'] = '含蓄内敛，通过行动和细节表达'
    elif 'T' in mbti_id:
        style['expression_way'] = '逻辑清晰，理性分析问题'
    else:
        style['expression_way'] = '情感丰富，注重感受和体验'
    
    # 倾听风格
    if 'F' in mbti_id:
        style['listening_style'] = '共情倾听，理解对方的情感需求'
    elif 'T' in mbti_id:
        style['listening_style'] = '分析倾听，关注问题和解决方案'
    else:
        style['listening_style'] = '开放倾听，接纳不同的观点'
    
    # 冲突时的沟通
    if element == '火象':
        style['conflict_communication'] = '直接面对，可能会情绪激动，但来得快去得快'
    elif element == '水象':
        style['conflict_communication'] = '倾向于回避，内心受伤，需要时间来平复'
    elif element == '风象':
        style['conflict_communication'] = '理性讨论，通过沟通寻找解决方案'
    elif element == '土象':
        style['conflict_communication'] = '冷静处理，务实解决具体问题'
    
    # 亲密沟通
    if element == '水象' or 'F' in mbti_id:
        style['intimacy_communication'] = '喜欢深度的情感交流，分享内心深处的想法'
    elif element == '火象':
        style['intimacy_communication'] = '热情直接，喜欢表达爱意和赞美'
    elif element == '风象':
        style['intimacy_communication'] = '通过智力交流和共同兴趣建立亲密感'
    else:
        style['intimacy_communication'] = '通过实际行动和稳定陪伴表达亲密'
    
    return style


def generate_conflict_style(zodiac, mbti):
    """生成冲突处理方式"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    style = {
        'trigger': '',
        'reaction': '',
        'resolution': '',
        'recovery': ''
    }
    
    # 触发点
    if element == '火象':
        style['trigger'] = '感到被限制、不被尊重或失去自由时容易爆发'
    elif element == '水象':
        style['trigger'] = '感到被忽视、情感需求不被满足时容易受伤'
    elif element == '风象':
        style['trigger'] = '感到被束缚、思想被否定或缺乏交流时容易不满'
    elif element == '土象':
        style['trigger'] = '感到不稳定、承诺被破坏或价值观冲突时容易生气'
    
    # 反应方式
    if 'T' in mbti_id:
        style['reaction'] = '理性分析冲突原因，试图找出逻辑解决方案'
    elif 'F' in mbti_id:
        style['reaction'] = '情感反应强烈，需要表达感受和获得理解'
    
    if element == '火象':
        style['reaction'] += '，可能会直接表达愤怒'
    elif element == '水象':
        style['reaction'] += '，可能会退缩或情绪化处理'
    
    # 解决方式
    if 'J' in mbti_id:
        style['resolution'] = '希望明确解决问题，制定具体的改进计划'
    else:
        style['resolution'] = '倾向于灵活处理，随着时间和自然发展化解'
    
    # 恢复速度
    if element == '火象':
        style['recovery'] = '恢复较快，不记仇，但可能会重复同样的冲突'
    elif element == '水象':
        style['recovery'] = '恢复较慢，需要时间和 reassurance，容易积累情绪'
    elif element == '风象':
        style['recovery'] = '通过沟通和理性分析恢复，但可能回避深层问题'
    elif element == '土象':
        style['recovery'] = '通过实际行动和稳定表现恢复，但需要看到改变'
    
    return style


def generate_emotional_needs(zodiac, mbti):
    """生成情感需求"""
    needs = {
        'primary_needs': [],
        'secondary_needs': [],
        'deal_breakers': []
    }
    
    # 主要需求
    zodiac_love_needs = zodiac['traits']['love']
    mbti_love_needs = mbti['love_needs']
    
    needs['primary_needs'].extend(zodiac_love_needs[:2])
    needs['primary_needs'].extend(mbti_love_needs[:2])
    
    # 次要需求
    element = zodiac['element']
    if element == '火象':
        needs['secondary_needs'].extend(['被欣赏', '自由空间', '激情保持'])
    elif element == '水象':
        needs['secondary_needs'].extend(['情感安全', '深度连接', '被理解'])
    elif element == '风象':
        needs['secondary_needs'].extend(['智力刺激', '社交自由', '思想交流'])
    elif element == '土象':
        needs['secondary_needs'].extend(['稳定承诺', '实际支持', '共同成长'])
    
    # 不能妥协的
    mbti_challenges = mbti['love_challenges']
    needs['deal_breakers'].extend([
        f"无法忍受{challenge}" for challenge in mbti_challenges[:2]
    ])
    
    return needs


def generate_intimacy_patterns(zodiac, mbti):
    """生成亲密关系中的行为模式"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    patterns = {
        'closeness_need': '',
        'independence_need': '',
        'affection_expression': '',
        'vulnerability': ''
    }
    
    # 亲密需求
    if element == '水象':
        patterns['closeness_need'] = '渴望深度的情感融合，希望与伴侣心灵相通'
    elif element == '火象':
        patterns['closeness_need'] = '喜欢热情的互动，通过活动和冒险增进亲密'
    elif element == '土象':
        patterns['closeness_need'] = '通过日常的陪伴和实际关怀建立亲密感'
    else:
        patterns['closeness_need'] = '通过思想交流和共同兴趣建立连接'
    
    # 独立需求
    if 'I' in mbti_id:
        patterns['independence_need'] = '需要独处时间充电，保持个人空间很重要'
    else:
        patterns['independence_need'] = '喜欢与伴侣一起社交，但也需要个人朋友圈'
    
    # 爱的表达
    patterns['affection_expression'] = zodiac['traits']['love'][0]
    
    # 脆弱性展现
    if element == '水象' or 'F' in mbti_id:
        patterns['vulnerability'] = '愿意展现脆弱，与伴侣分享深层情感'
    elif element == '土象' or 'T' in mbti_id:
        patterns['vulnerability'] = '较难展现脆弱，倾向于自己处理问题'
    else:
        patterns['vulnerability'] = '在感到安全时愿意展现真实自我'
    
    return patterns


def generate_long_term_potential(zodiac, mbti):
    """生成长期关系潜力"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    potential = {
        'commitment_level': '',
        'loyalty_style': '',
        'growth_mindset': '',
        'relationship_goals': ''
    }
    
    # 承诺程度
    if element == '土象' or 'J' in mbti_id:
        potential['commitment_level'] = '一旦承诺就会非常认真，重视长期稳定的关系'
    elif element == '火象' or 'P' in mbti_id:
        potential['commitment_level'] = '需要时间来确定，但一旦确定会非常投入'
    else:
        potential['commitment_level'] = '重视承诺，但也需要保持个人成长空间'
    
    # 忠诚方式
    if element == '水象':
        potential['loyalty_style'] = '情感忠诚，全心全意投入关系'
    elif element == '土象':
        potential['loyalty_style'] = '行动忠诚，通过实际付出证明爱意'
    elif element == '火象':
        potential['loyalty_style'] = '热情忠诚，保持关系的活力和激情'
    else:
        potential['loyalty_style'] = '思想忠诚，与伴侣保持精神上的共鸣'
    
    # 成长心态
    if 'N' in mbti_id:
        potential['growth_mindset'] = '重视共同成长，希望与伴侣一起探索和学习'
    else:
        potential['growth_mindset'] = '重视稳定成长，通过实际行动共同进步'
    
    # 关系目标
    if element == '土象':
        potential['relationship_goals'] = '建立稳定、安全、可预期的长期关系'
    elif element == '水象':
        potential['relationship_goals'] = '建立深度情感连接，成为彼此的灵魂伴侣'
    elif element == '火象':
        potential['relationship_goals'] = '保持关系的激情和活力，共同创造精彩人生'
    else:
        potential['relationship_goals'] = '建立互相尊重、思想契合的伙伴关系'
    
    return potential


def generate_best_matches(zodiac, mbti):
    """生成最佳匹配建议"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    matches = []
    
    # 基于元素的匹配
    if element == '火象':
        matches.extend([
            {'element': '风象', 'reason': '风助火势，思维活跃，互相激发'},
            {'element': '火象', 'reason': '同元素相吸，充满激情和活力'}
        ])
    elif element == '水象':
        matches.extend([
            {'element': '土象', 'reason': '土能蓄水，稳定安全，情感深厚'},
            {'element': '水象', 'reason': '同元素相融，深度情感连接'}
        ])
    elif element == '风象':
        matches.extend([
            {'element': '火象', 'reason': '火借风势，充满创意和活力'},
            {'element': '风象', 'reason': '同元素相通，思想契合'}
        ])
    elif element == '土象':
        matches.extend([
            {'element': '水象', 'reason': '水润土肥，温柔滋养，稳定持久'},
            {'element': '土象', 'reason': '同元素相守，务实稳定，目标一致'}
        ])
    
    # 基于MBTI的匹配
    if 'E' in mbti_id:
        matches.append({'mbti': 'I型', 'reason': '互补平衡，外向带动内向，内向给外向空间'})
    else:
        matches.append({'mbti': 'E型', 'reason': '互补平衡，内向提供深度，外向带来活力'})
    
    if 'T' in mbti_id:
        matches.append({'mbti': 'F型', 'reason': '理性与感性的平衡，互相学习'})
    else:
        matches.append({'mbti': 'T型', 'reason': '感性与理性的平衡，互相补充'})
    
    return matches


def generate_challenging_matches(zodiac, mbti):
    """生成需要努力的匹配"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    challenges = []
    
    # 基于元素的挑战
    if element == '火象':
        challenges.append({'element': '水象', 'challenge': '水火不容，一个热情一个敏感，需要互相理解'})
    elif element == '水象':
        challenges.append({'element': '火象', 'challenge': '水火相冲，一个内敛一个外放，需要找到平衡'})
    elif element == '风象':
        challenges.append({'element': '土象', 'challenge': '风土不合，一个飘忽一个固执，需要互相包容'})
    elif element == '土象':
        challenges.append({'element': '风象', 'challenge': '土风难融，一个务实一个随性，需要共同目标'})
    
    # 基于MBTI的挑战
    if 'J' in mbti_id:
        challenges.append({'mbti': 'P型', 'challenge': '计划与随性的冲突，需要互相妥协'})
    else:
        challenges.append({'mbti': 'J型', 'challenge': '随性与计划的矛盾，需要找到节奏'})
    
    return challenges


def generate_growth_areas(zodiac, mbti):
    """生成个人成长建议"""
    element = zodiac['element']
    mbti_id = mbti['id']
    
    growth = []
    
    # 基于星座的成长
    if element == '火象':
        growth.extend([
            '学会控制冲动，给关系沉淀的时间',
            '培养耐心，理解感情需要慢慢培养',
            '学会倾听，不只是表达自己'
        ])
    elif element == '水象':
        growth.extend([
            '建立情感界限，不要过度依赖',
            '学会理性分析，不被情绪左右',
            '增强自信，减少不安全感'
        ])
    elif element == '风象':
        growth.extend([
            '深入情感，不只是停留在表面',
            '建立承诺，给伴侣安全感',
            '专注当下，不要过度追求新鲜感'
        ])
    elif element == '土象':
        growth.extend([
            '学会表达情感，不只是用行动',
            '保持灵活性，接受变化',
            '放松完美主义，享受不完美'
        ])
    
    # 基于MBTI的成长
    if 'I' in mbti_id:
        growth.append('主动与伴侣分享想法，增进了解')
    else:
        growth.append('学会独处和反思，给关系空间')
    
    if 'T' in mbti_id:
        growth.append('关注伴侣的情感需求，而不只是问题')
    else:
        growth.append('保持理性，不被情绪完全控制')
    
    if 'J' in mbti_id:
        growth.append('学会接受不确定性，享受过程')
    else:
        growth.append('建立一些规划和目标，增加稳定性')
    
    return growth[:5]


def get_compatibility_with_mbti(zodiac1_id, mbti1_id, zodiac2_id, mbti2_id, gender1=None, gender2=None):
    """
    计算两个星座+MBTI组合的契合度
    可选传入性别参数进行更精准的分析
    """
    analysis1 = generate_combination_analysis(zodiac1_id, mbti1_id, gender1)
    analysis2 = generate_combination_analysis(zodiac2_id, mbti2_id, gender2)
    
    if not analysis1 or not analysis2:
        return None
    
    # 基础契合度（基于星座）
    from data.zodiac_data import get_compatibility
    base_compatibility = get_compatibility(zodiac1_id, zodiac2_id)
    base_score = base_compatibility['score'] if base_compatibility else 50
    
    # MBTI契合度计算
    mbti1 = analysis1['mbti']
    mbti2 = analysis2['mbti']
    
    mbti_score = calculate_mbti_compatibility(mbti1['id'], mbti2['id'])
    
    # 综合得分
    final_score = int((base_score * 0.6) + (mbti_score * 0.4))
    
    # 生成详细分析
    detailed_analysis = generate_detailed_compatibility(analysis1, analysis2)
    
    # 如果提供了性别信息，添加性别动态分析
    gender_analysis = None
    if gender1 and gender2:
        gender_analysis = get_compatibility_by_gender(
            analysis1['zodiac'], analysis1['mbti'], gender1,
            analysis2['zodiac'], analysis2['mbti'], gender2
        )
    
    result = {
        'score': final_score,
        'zodiac_compatibility': base_score,
        'mbti_compatibility': mbti_score,
        'analysis': detailed_analysis,
        'strengths': detailed_analysis['strengths'],
        'challenges': detailed_analysis['challenges'],
        'advice': detailed_analysis['advice']
    }
    
    if gender_analysis:
        result['gender_analysis'] = gender_analysis
    
    return result


def calculate_mbti_compatibility(mbti1_id, mbti2_id):
    """计算两个MBTI类型的契合度"""
    # 简化的MBTI契合度计算
    score = 70  # 基础分
    
    # 相同类型加分
    if mbti1_id == mbti2_id:
        score += 10
    
    # E-I 互补
    if ('E' in mbti1_id and 'I' in mbti2_id) or ('I' in mbti1_id and 'E' in mbti2_id):
        score += 5
    
    # S-N 相似更好
    if ('S' in mbti1_id and 'S' in mbti2_id) or ('N' in mbti1_id and 'N' in mbti2_id):
        score += 5
    
    # T-F 互补
    if ('T' in mbti1_id and 'F' in mbti2_id) or ('F' in mbti1_id and 'T' in mbti2_id):
        score += 5
    
    # J-P 互补
    if ('J' in mbti1_id and 'P' in mbti2_id) or ('P' in mbti1_id and 'J' in mbti2_id):
        score += 5
    
    return min(100, max(30, score))


def generate_detailed_compatibility(analysis1, analysis2):
    """生成详细的契合度分析"""
    zodiac1 = analysis1['zodiac']
    zodiac2 = analysis2['zodiac']
    mbti1 = analysis1['mbti']
    mbti2 = analysis2['mbti']
    
    strengths = []
    challenges = []
    advice = []
    
    # 分析优势
    if zodiac1['element'] == zodiac2['element']:
        strengths.append(f"同为{zodiac1['element']}星座，有相似的情感需求和价值观")
    
    if mbti1['id'][0] != mbti2['id'][0]:  # E-I 互补
        strengths.append(f"{mbti1['name']}与{mbti2['name']}性格互补，能互相平衡")
    
    # 分析挑战
    if zodiac1['element'] in ['火象', '水象'] and zodiac2['element'] in ['火象', '水象']:
        if zodiac1['element'] != zodiac2['element']:
            challenges.append("水火相冲，情感表达方式差异大，需要互相理解")
    
    # 建议
    advice.append("尊重彼此的差异，学会欣赏对方的独特之处")
    advice.append("多沟通，了解对方的情感需求和表达方式")
    
    return {
        'strengths': strengths,
        'challenges': challenges,
        'advice': advice
    }

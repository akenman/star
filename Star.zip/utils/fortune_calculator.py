import random
import hashlib
from datetime import datetime

def calculate_daily_fortune(zodiac_id, date=None):
    """
    计算每日运势
    基于星座和日期生成稳定的运势预测
    """
    if date is None:
        date = datetime.now()
    
    # 生成基于星座和日期的种子
    date_str = date.strftime('%Y-%m-%d')
    seed_str = f"{zodiac_id}_{date_str}"
    seed = int(hashlib.md5(seed_str.encode()).hexdigest(), 16)
    random.seed(seed)
    
    # 运势关键词
    overall_keywords = ['大吉', '吉', '平', '凶', '大凶']
    love_keywords = ['桃花运旺', '稳定发展', '需要沟通', '小心误会', '独处为佳']
    career_keywords = ['升职加薪', '贵人相助', '稳扎稳打', '谨慎决策', '避免冲突']
    wealth_keywords = ['财源广进', '小有收获', '收支平衡', '控制开支', '避免投资']
    health_keywords = ['精力充沛', '状态良好', '注意休息', '预防小病', '调养身体']
    
    # 生成运势
    fortune = {
        'date': date.strftime('%Y年%m月%d日'),
        'zodiac': zodiac_id,
        'overall': {
            'score': random.randint(50, 100),
            'level': '',
            'desc': ''
        },
        'love': {
            'score': random.randint(40, 100),
            'keyword': '',
            'desc': ''
        },
        'career': {
            'score': random.randint(40, 100),
            'keyword': '',
            'desc': ''
        },
        'wealth': {
            'score': random.randint(30, 100),
            'keyword': '',
            'desc': ''
        },
        'health': {
            'score': random.randint(50, 100),
            'keyword': '',
            'desc': ''
        },
        'lucky': {
            'numbers': [random.randint(1, 99) for _ in range(3)],
            'color': random.choice([
                {'name': '红色', 'hex': '#e74c3c'},
                {'name': '橙色', 'hex': '#e67e22'},
                {'name': '黄色', 'hex': '#f1c40f'},
                {'name': '绿色', 'hex': '#27ae60'},
                {'name': '青色', 'hex': '#16a085'},
                {'name': '蓝色', 'hex': '#2980b9'},
                {'name': '紫色', 'hex': '#8e44ad'},
                {'name': '粉色', 'hex': '#ff6b9d'},
                {'name': '白色', 'hex': '#ecf0f1'},
                {'name': '黑色', 'hex': '#2c3e50'},
                {'name': '金色', 'hex': '#f39c12'},
                {'name': '银色', 'hex': '#bdc3c7'}
            ]),
            'direction': random.choice(['东', '南', '西', '北', '东南', '东北', '西南', '西北']),
            'item': random.choice(['水晶', '玉石', '书籍', '鲜花', '巧克力', '手表', '钱包', '钥匙扣', '手链', '项链', '香水', '笔记本'])
        },
        'advice': random.choice([
            '保持积极乐观的心态，好运自然来',
            '相信直觉，但也要理性分析',
            '多与朋友交流，会有意外收获',
            '适当放慢脚步，享受当下',
            '勇敢尝试新事物，突破自我',
            '保持谦逊，虚心学习',
            '关爱身边的人，传递正能量',
            '坚持自己的原则，不随波逐流',
            '学会放松，给自己充电',
            '珍惜眼前人，把握当下'
        ])
    }
    
    # 设置等级和描述
    overall_score = fortune['overall']['score']
    if overall_score >= 90:
        fortune['overall']['level'] = '大吉'
        fortune['overall']['desc'] = '今日运势极佳，适合主动出击，把握机会'
    elif overall_score >= 80:
        fortune['overall']['level'] = '吉'
        fortune['overall']['desc'] = '能量满满的一天，事情进展顺利'
    elif overall_score >= 70:
        fortune['overall']['level'] = '中吉'
        fortune['overall']['desc'] = '贵人运旺，容易得到他人帮助'
    elif overall_score >= 60:
        fortune['overall']['level'] = '平'
        fortune['overall']['desc'] = '运势平稳，按部就班即可'
    elif overall_score >= 50:
        fortune['overall']['level'] = '凶'
        fortune['overall']['desc'] = '运势低迷，建议低调行事'
    else:
        fortune['overall']['level'] = '大凶'
        fortune['overall']['desc'] = '容易遇到阻碍，需要耐心'
    
    # 爱情运势
    love_score = fortune['love']['score']
    if love_score >= 80:
        fortune['love']['keyword'] = '桃花运旺'
        fortune['love']['desc'] = '桃花运旺盛，单身者有机会遇到心仪对象'
    elif love_score >= 60:
        fortune['love']['keyword'] = '稳定发展'
        fortune['love']['desc'] = '感情平稳，适合深入交流'
    elif love_score >= 40:
        fortune['love']['keyword'] = '需要沟通'
        fortune['love']['desc'] = '需要主动沟通，避免误会'
    else:
        fortune['love']['keyword'] = '小心误会'
        fortune['love']['desc'] = '容易产生误会，说话需谨慎'
    
    # 事业运势
    career_score = fortune['career']['score']
    if career_score >= 80:
        fortune['career']['keyword'] = '升职加薪'
        fortune['career']['desc'] = '工作效率高，容易获得认可'
    elif career_score >= 60:
        fortune['career']['keyword'] = '贵人相助'
        fortune['career']['desc'] = '工作平稳，按计划推进'
    elif career_score >= 40:
        fortune['career']['keyword'] = '稳扎稳打'
        fortune['career']['desc'] = '需要更多耐心处理事务'
    else:
        fortune['career']['keyword'] = '谨慎决策'
        fortune['career']['desc'] = '工作压力较大，注意调节'
    
    # 财富运势
    wealth_score = fortune['wealth']['score']
    if wealth_score >= 80:
        fortune['wealth']['keyword'] = '财源广进'
        fortune['wealth']['desc'] = '财运亨通，可能有意外之财'
    elif wealth_score >= 60:
        fortune['wealth']['keyword'] = '小有收获'
        fortune['wealth']['desc'] = '收支平衡，理性消费'
    elif wealth_score >= 40:
        fortune['wealth']['keyword'] = '收支平衡'
        fortune['wealth']['desc'] = '避免冲动购物'
    else:
        fortune['wealth']['keyword'] = '控制开支'
        fortune['wealth']['desc'] = '控制开支，避免浪费'
    
    # 健康运势
    health_score = fortune['health']['score']
    if health_score >= 80:
        fortune['health']['keyword'] = '精力充沛'
        fortune['health']['desc'] = '精力充沛，适合运动锻炼'
    elif health_score >= 60:
        fortune['health']['keyword'] = '状态良好'
        fortune['health']['desc'] = '注意休息，不要过度劳累'
    elif health_score >= 40:
        fortune['health']['keyword'] = '注意休息'
        fortune['health']['desc'] = '保持规律作息'
    else:
        fortune['health']['keyword'] = '预防小病'
        fortune['health']['desc'] = '容易疲劳，需要多休息'
    
    # 重置随机种子
    random.seed()
    
    return fortune


def get_weekly_fortune(zodiac_id, start_date=None):
    """获取一周运势"""
    if start_date is None:
        start_date = datetime.now()
    
    weekly = []
    for i in range(7):
        from datetime import timedelta
        date = start_date + timedelta(days=i)
        weekly.append(calculate_daily_fortune(zodiac_id, date))
    
    return weekly

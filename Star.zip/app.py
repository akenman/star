from flask import Flask, render_template, jsonify, request
from data.zodiac_data import zodiac_signs, compatibility_matrix, get_zodiac_by_id, get_compatibility
from data.mbti_data import mbti_types, get_mbti_by_id, get_all_mbti
from utils.fortune_calculator import calculate_daily_fortune
from utils.zodiac_mbti_analyzer import generate_combination_analysis, get_compatibility_with_mbti
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', zodiac_signs=zodiac_signs, mbti_types=mbti_types)

# 星座相关API
@app.route('/api/compatibility', methods=['POST'])
def api_compatibility():
    data = request.get_json()
    sign1 = data.get('sign1')
    sign2 = data.get('sign2')
    
    if not sign1 or not sign2:
        return jsonify({'error': '请提供两个星座'}), 400
    
    result = get_compatibility(sign1, sign2)
    sign1_data = get_zodiac_by_id(sign1)
    sign2_data = get_zodiac_by_id(sign2)
    
    return jsonify({
        'result': result,
        'sign1': sign1_data,
        'sign2': sign2_data
    })

@app.route('/api/fortune/<zodiac_id>')
def api_fortune(zodiac_id):
    fortune = calculate_daily_fortune(zodiac_id)
    return jsonify(fortune)

@app.route('/api/zodiac/<zodiac_id>')
def api_zodiac(zodiac_id):
    zodiac = get_zodiac_by_id(zodiac_id)
    if not zodiac:
        return jsonify({'error': '星座不存在'}), 404
    return jsonify(zodiac)

@app.route('/api/zodiacs')
def api_zodiacs():
    return jsonify(zodiac_signs)

# MBTI相关API
@app.route('/api/mbti/<mbti_id>')
def api_mbti(mbti_id):
    mbti = get_mbti_by_id(mbti_id.upper())
    if not mbti:
        return jsonify({'error': 'MBTI类型不存在'}), 404
    return jsonify(mbti)

@app.route('/api/mbtis')
def api_mbtis():
    return jsonify(mbti_types)

# 星座+MBTI组合分析API（支持性别参数）
@app.route('/api/zodiac-mbti/<zodiac_id>/<mbti_id>')
def api_zodiac_mbti(zodiac_id, mbti_id):
    # 获取可选的性别参数
    gender = request.args.get('gender', None)
    
    analysis = generate_combination_analysis(zodiac_id, mbti_id.upper(), gender)
    if not analysis:
        return jsonify({'error': '星座或MBTI类型不存在'}), 404
    return jsonify(analysis)

# 组合契合度API（支持性别参数）
@app.route('/api/compatibility-mbti', methods=['POST'])
def api_compatibility_mbti():
    data = request.get_json()
    zodiac1 = data.get('zodiac1')
    mbti1 = data.get('mbti1')
    zodiac2 = data.get('zodiac2')
    mbti2 = data.get('mbti2')
    gender1 = data.get('gender1')  # 可选参数
    gender2 = data.get('gender2')  # 可选参数
    
    if not all([zodiac1, mbti1, zodiac2, mbti2]):
        return jsonify({'error': '请提供完整的星座和MBTI信息'}), 400
    
    result = get_compatibility_with_mbti(
        zodiac1, mbti1.upper(), zodiac2, mbti2.upper(),
        gender1, gender2
    )
    
    if not result:
        return jsonify({'error': '计算失败'}), 500
    
    # 添加双方详细信息
    analysis1 = generate_combination_analysis(zodiac1, mbti1.upper(), gender1)
    analysis2 = generate_combination_analysis(zodiac2, mbti2.upper(), gender2)
    
    return jsonify({
        'result': result,
        'person1': analysis1,
        'person2': analysis2
    })

if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)

<template>
  <div class="container">
    <header class="app-header">
      <h1 class="title">✨ 星座契合度与运势</h1>
      <p class="subtitle">探索星座之间的奥秘，了解你的运势走向</p>
    </header>
    
    <nav class="tab-container">
      <div 
        class="tab" 
        :class="{ active: currentTab === 'compatibility' }"
        @click="currentTab = 'compatibility'"
      >
        💕 星座契合度
      </div>
      <div 
        class="tab" 
        :class="{ active: currentTab === 'fortune' }"
        @click="currentTab = 'fortune'"
      >
        🔮 今日运势
      </div>
      <div 
        class="tab" 
        :class="{ active: currentTab === 'explore' }"
        @click="currentTab = 'explore'"
      >
        🌟 星座探索
      </div>
    </nav>
    
    <main class="main-content">
      <Transition name="fade" mode="out-in">
        <!-- 星座契合度页面 -->
        <div v-if="currentTab === 'compatibility'" key="compatibility" class="tab-content">
          <div class="card">
            <ZodiacSelector 
              v-model="compatibilitySign1" 
              title="选择你的星座"
            />
            <ZodiacSelector 
              v-model="compatibilitySign2" 
              title="选择TA的星座"
            />
            
            <div class="action-area">
              <button 
                class="btn" 
                :disabled="!canCalculateCompatibility"
                @click="calculateCompatibility"
              >
                查看契合度
              </button>
            </div>
            
            <CompatibilityResult 
              v-if="compatibilityResult" 
              :result="compatibilityResult"
              :sign1-id="compatibilitySign1"
              :sign2-id="compatibilitySign2"
            />
          </div>
        </div>
        
        <!-- 今日运势页面 -->
        <div v-else-if="currentTab === 'fortune'" key="fortune" class="tab-content">
          <div class="card">
            <ZodiacSelector 
              v-model="fortuneSign" 
              title="选择你的星座查看运势"
            />
            
            <div class="action-area">
              <button 
                class="btn" 
                :disabled="!fortuneSign"
                @click="generateFortune"
              >
                查看今日运势
              </button>
            </div>
            
            <FortuneDisplay v-if="fortuneResult" :fortune="fortuneResult" />
          </div>
        </div>
        
        <!-- 星座探索页面 -->
        <div v-else key="explore" class="tab-content">
          <div class="explore-container">
            <div class="card">
              <h3 class="explore-title">🌟 探索十二星座</h3>
              <p class="explore-subtitle">点击任意星座了解详细性格特点</p>
              
              <div class="explore-grid">
                <div 
                  v-for="sign in zodiacSigns" 
                  :key="sign.id"
                  class="explore-item"
                  @click="selectedSign = sign"
                >
                  <span class="explore-emoji">{{ sign.emoji }}</span>
                  <span class="explore-name">{{ sign.name }}</span>
                  <span class="explore-element">{{ sign.element }}</span>
                </div>
              </div>
            </div>
            
            <div v-if="selectedSign" class="card sign-detail">
              <div class="detail-header">
                <span class="detail-emoji">{{ selectedSign.emoji }}</span>
                <div class="detail-title">
                  <h3>{{ selectedSign.name }}</h3>
                  <p>{{ selectedSign.date }} · {{ selectedSign.element }}</p>
                </div>
              </div>
              
              <p class="detail-description">{{ selectedSign.description }}</p>
              
              <div class="detail-sections">
                <div class="detail-section">
                  <h4>性格特点</h4>
                  <div class="trait-tags">
                    <span v-for="trait in selectedSign.traits.personality" :key="trait" class="trait-tag">
                      {{ trait }}
                    </span>
                  </div>
                </div>
                
                <div class="detail-section">
                  <h4>优点</h4>
                  <ul>
                    <li v-for="strength in selectedSign.traits.strengths" :key="strength">
                      {{ strength }}
                    </li>
                  </ul>
                </div>
                
                <div class="detail-section">
                  <h4>缺点</h4>
                  <ul>
                    <li v-for="weakness in selectedSign.traits.weaknesses" :key="weakness">
                      {{ weakness }}
                    </li>
                  </ul>
                </div>
                
                <div class="detail-section">
                  <h4>爱情观</h4>
                  <ul>
                    <li v-for="love in selectedSign.traits.love" :key="love">
                      {{ love }}
                    </li>
                  </ul>
                </div>
                
                <div class="detail-section warning">
                  <h4>💝 情感相处中可能遇到的问题</h4>
                  <ul>
                    <li v-for="problem in selectedSign.loveProblems" :key="problem">
                      {{ problem }}
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </main>
    
    <footer class="app-footer">
      <p>✨ 星座运势仅供参考，人生掌握在自己手中 ✨</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { zodiacSigns, getCompatibility } from './data/zodiacData.js'
import { calculateDailyFortune } from './utils/fortuneCalculator.js'
import ZodiacSelector from './components/ZodiacSelector.vue'
import CompatibilityResult from './components/CompatibilityResult.vue'
import FortuneDisplay from './components/FortuneDisplay.vue'

const currentTab = ref('compatibility')

// 契合度相关
const compatibilitySign1 = ref('')
const compatibilitySign2 = ref('')
const compatibilityResult = ref(null)

const canCalculateCompatibility = computed(() => {
  return compatibilitySign1.value && compatibilitySign2.value
})

const calculateCompatibility = () => {
  compatibilityResult.value = getCompatibility(
    compatibilitySign1.value, 
    compatibilitySign2.value
  )
}

// 运势相关
const fortuneSign = ref('')
const fortuneResult = ref(null)

const generateFortune = () => {
  fortuneResult.value = calculateDailyFortune(fortuneSign.value)
}

// 探索相关
const selectedSign = ref(null)
</script>

<style scoped>
.app-header {
  margin-bottom: 30px;
}

.main-content {
  margin-bottom: 30px;
}

.tab-content {
  max-width: 800px;
  margin: 0 auto;
}

.action-area {
  text-align: center;
  margin: 24px 0;
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.explore-container {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.explore-title {
  text-align: center;
  font-size: 1.3rem;
  margin-bottom: 8px;
}

.explore-subtitle {
  text-align: center;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 20px;
  font-size: 0.9rem;
}

.explore-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 12px;
}

.explore-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 12px;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.explore-item:hover {
  background: rgba(255, 255, 255, 0.1);
  transform: translateY(-5px);
  border-color: rgba(102, 126, 234, 0.5);
}

.explore-emoji {
  font-size: 2.5rem;
  margin-bottom: 8px;
}

.explore-name {
  font-size: 1rem;
  font-weight: 500;
  margin-bottom: 4px;
}

.explore-element {
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.5);
}

.sign-detail {
  animation: slideUp 0.4s ease;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.detail-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.detail-emoji {
  font-size: 4rem;
}

.detail-title h3 {
  font-size: 1.8rem;
  margin-bottom: 4px;
}

.detail-title p {
  color: rgba(255, 255, 255, 0.6);
}

.detail-description {
  font-size: 1.1rem;
  line-height: 1.7;
  color: rgba(255, 255, 255, 0.85);
  margin-bottom: 24px;
  padding: 16px;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
}

.detail-sections {
  display: grid;
  gap: 20px;
}

.detail-section {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  padding: 16px;
}

.detail-section.warning {
  background: rgba(231, 76, 60, 0.1);
  border: 1px solid rgba(231, 76, 60, 0.3);
}

.detail-section h4 {
  font-size: 1rem;
  margin-bottom: 12px;
  color: rgba(255, 255, 255, 0.9);
}

.trait-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.trait-tag {
  padding: 6px 14px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.3), rgba(118, 75, 162, 0.3));
  border-radius: 20px;
  font-size: 0.9rem;
}

.detail-section ul {
  list-style: none;
  padding: 0;
}

.detail-section li {
  padding: 6px 0;
  padding-left: 20px;
  position: relative;
  color: rgba(255, 255, 255, 0.8);
}

.detail-section li::before {
  content: '•';
  position: absolute;
  left: 0;
  color: #667eea;
}

.detail-section.warning li::before {
  color: #e74c3c;
}

.app-footer {
  text-align: center;
  padding: 20px;
  color: rgba(255, 255, 255, 0.5);
  font-size: 0.9rem;
}

@media (max-width: 768px) {
  .explore-grid {
    grid-template-columns: repeat(3, 1fr);
  }
  
  .explore-item {
    padding: 16px 8px;
  }
  
  .explore-emoji {
    font-size: 2rem;
  }
  
  .detail-emoji {
    font-size: 3rem;
  }
  
  .detail-title h3 {
    font-size: 1.4rem;
  }
}
</style>

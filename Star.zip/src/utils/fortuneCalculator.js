import { getFortuneKeywords } from '../data/zodiacData.js'

export function calculateDailyFortune(zodiacId, date = new Date()) {
  const seed = generateSeed(zodiacId, date)
  const keywords = getFortuneKeywords()
  
  const fortune = {
    date: formatDate(date),
    zodiac: zodiacId,
    overall: {
      score: randomScore(seed, 50, 100),
      level: '',
      desc: ''
    },
    love: {
      score: randomScore(seed + 1, 40, 100),
      keyword: '',
      desc: ''
    },
    career: {
      score: randomScore(seed + 2, 40, 100),
      keyword: '',
      desc: ''
    },
    wealth: {
      score: randomScore(seed + 3, 30, 100),
      keyword: '',
      desc: ''
    },
    health: {
      score: randomScore(seed + 4, 50, 100),
      keyword: '',
      desc: ''
    },
    lucky: {
      number: randomLuckyNumber(seed),
      color: randomLuckyColor(seed),
      direction: randomDirection(seed),
      item: randomLuckyItem(seed)
    },
    advice: generateAdvice(seed, zodiacId)
  }
  
  fortune.overall.level = getOverallLevel(fortune.overall.score)
  fortune.overall.desc = generateOverallDesc(fortune.overall.score, seed)
  
  fortune.love.keyword = keywords.love[Math.floor(randomScore(seed + 10, 0, 5))]
  fortune.love.desc = generateLoveDesc(fortune.love.score, seed)
  
  fortune.career.keyword = keywords.career[Math.floor(randomScore(seed + 20, 0, 5))]
  fortune.career.desc = generateCareerDesc(fortune.career.score, seed)
  
  fortune.wealth.keyword = keywords.wealth[Math.floor(randomScore(seed + 30, 0, 5))]
  fortune.wealth.desc = generateWealthDesc(fortune.wealth.score, seed)
  
  fortune.health.keyword = keywords.health[Math.floor(randomScore(seed + 40, 0, 5))]
  fortune.health.desc = generateHealthDesc(fortune.health.score, seed)
  
  return fortune
}

function generateSeed(zodiacId, date) {
  const dateStr = date.toISOString().split('T')[0]
  let hash = 0
  const str = zodiacId + dateStr
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return Math.abs(hash)
}

function randomScore(seed, min, max) {
  const x = Math.sin(seed) * 10000
  const random = x - Math.floor(x)
  return Math.floor(random * (max - min + 1)) + min
}

function formatDate(date) {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const weekDays = ['日', '一', '二', '三', '四', '五', '六']
  const weekDay = weekDays[date.getDay()]
  return `${year}年${month}月${day}日 星期${weekDay}`
}

function getOverallLevel(score) {
  if (score >= 90) return '大吉'
  if (score >= 80) return '吉'
  if (score >= 70) return '中吉'
  if (score >= 60) return '平'
  if (score >= 50) return '凶'
  return '大凶'
}

function generateOverallDesc(score, seed) {
  const goodDescs = [
    '今日运势极佳，适合主动出击，把握机会',
    '能量满满的一天，事情进展顺利',
    '贵人运旺，容易得到他人帮助',
    '心情愉悦，适合社交和表达',
    '直觉敏锐，适合做重要决定'
  ]
  const normalDescs = [
    '运势平稳，按部就班即可',
    '小有起伏，保持平常心',
    '需要耐心等待机会',
    '适合反思和规划',
    '注意细节，避免小失误'
  ]
  const badDescs = [
    '运势低迷，建议低调行事',
    '容易遇到阻碍，需要耐心',
    '情绪波动，注意调节心态',
    '避免重要决策，暂缓行动',
    '多休息，不要勉强自己'
  ]
  
  const index = randomScore(seed + 100, 0, 4)
  if (score >= 70) return goodDescs[index]
  if (score >= 50) return normalDescs[index]
  return badDescs[index]
}

function generateLoveDesc(score, seed) {
  const goodDescs = [
    '桃花运旺盛，单身者有机会遇到心仪对象',
    '感情甜蜜，适合表达爱意',
    '与伴侣关系融洽，互相理解',
    '魅力值上升，容易吸引异性',
    '适合约会或表白，成功率高'
  ]
  const normalDescs = [
    '感情平稳，适合深入交流',
    '需要主动沟通，避免误会',
    '给彼此一些空间会更好',
    '适合一起规划未来',
    '平淡中见真情'
  ]
  const badDescs = [
    '容易产生误会，说话需谨慎',
    '情绪敏感，避免争吵',
    '单身者不宜急于表白',
    '给彼此一些冷静的时间',
    '专注自我提升，缘分自来'
  ]
  
  const index = randomScore(seed + 200, 0, 4)
  if (score >= 70) return goodDescs[index]
  if (score >= 50) return normalDescs[index]
  return badDescs[index]
}

function generateCareerDesc(score, seed) {
  const goodDescs = [
    '工作效率高，容易获得认可',
    '有升职加薪的机会',
    '贵人相助，项目进展顺利',
    '创意灵感迸发，适合创新',
    '领导能力得到展现'
  ]
  const normalDescs = [
    '工作平稳，按计划推进',
    '需要更多耐心处理事务',
    '适合学习新技能',
    '与同事保持良好沟通',
    '稳扎稳打，不要冒进'
  ]
  const badDescs = [
    '工作压力较大，注意调节',
    '避免与同事发生冲突',
    '重要决策需要谨慎',
    '可能会遇到阻碍，保持耐心',
    '专注完成手头工作'
  ]
  
  const index = randomScore(seed + 300, 0, 4)
  if (score >= 70) return goodDescs[index]
  if (score >= 50) return normalDescs[index]
  return badDescs[index]
}

function generateWealthDesc(score, seed) {
  const goodDescs = [
    '财运亨通，可能有意外之财',
    '投资眼光准确，收益可观',
    '适合理财规划，储蓄增加',
    '有赚钱的好机会',
    '偏财运旺，可小试手气'
  ]
  const normalDescs = [
    '收支平衡，理性消费',
    '避免冲动购物',
    '适合制定预算计划',
    '小额投资可以考虑',
    '稳健理财为上策'
  ]
  const badDescs = [
    '控制开支，避免浪费',
    '不宜进行大额投资',
    '谨防财务陷阱',
    '借钱需谨慎',
    '保守理财，现金为王'
  ]
  
  const index = randomScore(seed + 400, 0, 4)
  if (score >= 70) return goodDescs[index]
  if (score >= 50) return normalDescs[index]
  return badDescs[index]
}

function generateHealthDesc(score, seed) {
  const goodDescs = [
    '精力充沛，适合运动锻炼',
    '身体状态良好，心情愉悦',
    '免疫力强，不易生病',
    '适合开始新的健康计划',
    '身心平衡，状态上佳'
  ]
  const normalDescs = [
    '注意休息，不要过度劳累',
    '保持规律作息',
    '适当运动，增强体质',
    '饮食清淡，注意营养',
    '放松心情，缓解压力'
  ]
  const badDescs = [
    '容易疲劳，需要多休息',
    '注意预防感冒等小病痛',
    '避免熬夜，保证睡眠',
    '饮食要注意卫生',
    '如有不适及时就医'
  ]
  
  const index = randomScore(seed + 500, 0, 4)
  if (score >= 70) return goodDescs[index]
  if (score >= 50) return normalDescs[index]
  return badDescs[index]
}

function randomLuckyNumber(seed) {
  const numbers = []
  for (let i = 0; i < 3; i++) {
    numbers.push(randomScore(seed + i * 10, 1, 99))
  }
  return numbers
}

function randomLuckyColor(seed) {
  const colors = [
    { name: '红色', hex: '#e74c3c' },
    { name: '橙色', hex: '#e67e22' },
    { name: '黄色', hex: '#f1c40f' },
    { name: '绿色', hex: '#27ae60' },
    { name: '青色', hex: '#16a085' },
    { name: '蓝色', hex: '#2980b9' },
    { name: '紫色', hex: '#8e44ad' },
    { name: '粉色', hex: '#ff6b9d' },
    { name: '白色', hex: '#ecf0f1' },
    { name: '黑色', hex: '#2c3e50' },
    { name: '金色', hex: '#f39c12' },
    { name: '银色', hex: '#bdc3c7' }
  ]
  return colors[randomScore(seed + 600, 0, colors.length - 1)]
}

function randomDirection(seed) {
  const directions = ['东', '南', '西', '北', '东南', '东北', '西南', '西北']
  return directions[randomScore(seed + 700, 0, directions.length - 1)]
}

function randomLuckyItem(seed) {
  const items = [
    '水晶', '玉石', '书籍', '鲜花', '巧克力',
    '手表', '钱包', '钥匙扣', '手链', '项链',
    '香水', '笔记本', '茶杯', '抱枕', '围巾'
  ]
  return items[randomScore(seed + 800, 0, items.length - 1)]
}

function generateAdvice(seed, zodiacId) {
  const advices = [
    '保持积极乐观的心态，好运自然来',
    '相信直觉，但也要理性分析',
    '多与朋友交流，会有意外收获',
    '适当放慢脚步，享受当下',
    '勇敢尝试新事物，突破自我',
    '保持谦逊，虚心学习',
    '关爱身边的人，传递正能量',
    '坚持自己的原则，不随波逐流',
    '学会放松，给自己充电',
    '珍惜眼前人，把握当下'
  ]
  return advices[randomScore(seed + 900, 0, advices.length - 1)]
}

export function getWeeklyFortune(zodiacId, startDate = new Date()) {
  const weekly = []
  for (let i = 0; i < 7; i++) {
    const date = new Date(startDate)
    date.setDate(date.getDate() + i)
    weekly.push(calculateDailyFortune(zodiacId, date))
  }
  return weekly
}

<template>
  <div v-if="result" class="compatibility-result">
    <div class="result-header">
      <div class="signs-display">
        <div class="sign-badge">
          <span class="sign-emoji">{{ sign1?.emoji }}</span>
          <span class="sign-name">{{ sign1?.name }}</span>
        </div>
        <div class="heart-icon">💕</div>
        <div class="sign-badge">
          <span class="sign-emoji">{{ sign2?.emoji }}</span>
          <span class="sign-name">{{ sign2?.name }}</span>
        </div>
      </div>
      
      <div class="score-section">
        <div class="score-circle" :style="scoreStyle">
          <span class="score-value">{{ result.score }}</span>
          <span class="score-label">契合度</span>
        </div>
      </div>
    </div>
    
    <div class="result-desc">
      <p>{{ result.desc }}</p>
    </div>
    
    <div class="analysis-sections">
      <div class="analysis-card">
        <h4>💝 情感相处建议</h4>
        <ul>
          <li v-for="(problem, index) in relationshipProblems" :key="index">
            {{ problem }}
          </li>
        </ul>
      </div>
      
      <div class="analysis-card">
        <h4>✨ 优势组合</h4>
        <div class="strength-tags">
          <span v-for="(strength, index) in combinedStrengths" :key="index" class="tag">
            {{ strength }}
          </span>
        </div>
      </div>
      
      <div class="analysis-card">
        <h4>⚠️ 需要注意</h4>
        <div class="weakness-tags">
          <span v-for="(weakness, index) in combinedWeaknesses" :key="index" class="tag warning">
            {{ weakness }}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { getZodiacById } from '../data/zodiacData.js'

const props = defineProps({
  result: {
    type: Object,
    default: null
  },
  sign1Id: {
    type: String,
    default: ''
  },
  sign2Id: {
    type: String,
    default: ''
  }
})

const sign1 = computed(() => getZodiacById(props.sign1Id))
const sign2 = computed(() => getZodiacById(props.sign2Id))

const scoreStyle = computed(() => {
  const score = props.result?.score || 0
  let color = '#e74c3c'
  if (score >= 80) color = '#27ae60'
  else if (score >= 60) color = '#f39c12'
  else if (score >= 40) color = '#e67e22'
  
  return {
    background: `conic-gradient(${color} ${score * 3.6}deg, rgba(255,255,255,0.1) 0deg)`,
    boxShadow: `0 0 30px ${color}40`
  }
})

const relationshipProblems = computed(() => {
  const problems = []
  if (sign1.value?.loveProblems) {
    problems.push(...sign1.value.loveProblems.slice(0, 3))
  }
  if (sign2.value?.loveProblems) {
    problems.push(...sign2.value.loveProblems.slice(0, 2))
  }
  return [...new Set(problems)].slice(0, 5)
})

const combinedStrengths = computed(() => {
  const strengths = []
  if (sign1.value?.traits.strengths) {
    strengths.push(...sign1.value.traits.strengths.slice(0, 3))
  }
  if (sign2.value?.traits.strengths) {
    strengths.push(...sign2.value.traits.strengths.slice(0, 2))
  }
  return [...new Set(strengths)].slice(0, 5)
})

const combinedWeaknesses = computed(() => {
  const weaknesses = []
  if (sign1.value?.traits.weaknesses) {
    weaknesses.push(...sign1.value.traits.weaknesses.slice(0, 2))
  }
  if (sign2.value?.traits.weaknesses) {
    weaknesses.push(...sign2.value.traits.weaknesses.slice(0, 2))
  }
  return [...new Set(weaknesses)].slice(0, 4)
})
</script>

<style scoped>
.compatibility-result {
  animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.result-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 24px;
}

.signs-display {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 20px;
}

.sign-badge {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px 24px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 16px;
}

.sign-emoji {
  font-size: 2.5rem;
  margin-bottom: 8px;
}

.sign-name {
  font-size: 1.1rem;
  font-weight: 500;
}

.heart-icon {
  font-size: 2rem;
  animation: heartbeat 1.5s ease-in-out infinite;
}

@keyframes heartbeat {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.2); }
}

.score-section {
  margin-top: 10px;
}

.score-circle {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
}

.score-circle::before {
  content: '';
  position: absolute;
  width: 100px;
  height: 100px;
  background: rgba(26, 26, 46, 0.9);
  border-radius: 50%;
}

.score-value {
  font-size: 2.5rem;
  font-weight: bold;
  position: relative;
  z-index: 1;
}

.score-label {
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.7);
  position: relative;
  z-index: 1;
}

.result-desc {
  text-align: center;
  padding: 16px;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  margin-bottom: 24px;
}

.result-desc p {
  font-size: 1.1rem;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.9);
}

.analysis-sections {
  display: grid;
  gap: 16px;
}

.analysis-card {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  padding: 16px;
}

.analysis-card h4 {
  margin-bottom: 12px;
  font-size: 1rem;
  color: rgba(255, 255, 255, 0.9);
}

.analysis-card ul {
  list-style: none;
  padding: 0;
}

.analysis-card li {
  padding: 8px 0;
  padding-left: 20px;
  position: relative;
  color: rgba(255, 255, 255, 0.8);
  font-size: 0.95rem;
}

.analysis-card li::before {
  content: '•';
  position: absolute;
  left: 0;
  color: #667eea;
}

.strength-tags, .weakness-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tag {
  padding: 6px 14px;
  background: rgba(102, 126, 234, 0.3);
  border-radius: 20px;
  font-size: 0.85rem;
  color: rgba(255, 255, 255, 0.9);
}

.tag.warning {
  background: rgba(231, 76, 60, 0.3);
}

@media (max-width: 768px) {
  .signs-display {
    gap: 12px;
  }
  
  .sign-badge {
    padding: 12px 16px;
  }
  
  .sign-emoji {
    font-size: 2rem;
  }
  
  .sign-name {
    font-size: 0.9rem;
  }
  
  .score-circle {
    width: 100px;
    height: 100px;
  }
  
  .score-circle::before {
    width: 80px;
    height: 80px;
  }
  
  .score-value {
    font-size: 2rem;
  }
}
</style>

<template>
  <div v-if="fortune" class="fortune-display">
    <div class="fortune-header">
      <div class="zodiac-info">
        <span class="zodiac-emoji">{{ zodiacInfo?.emoji }}</span>
        <div class="zodiac-details">
          <h3>{{ zodiacInfo?.name }}</h3>
          <p class="fortune-date">{{ fortune.date }}</p>
        </div>
      </div>
      <div class="overall-score">
        <div class="score-badge" :class="scoreClass">
          <span class="score-number">{{ fortune.overall.score }}</span>
          <span class="score-level">{{ fortune.overall.level }}</span>
        </div>
      </div>
    </div>
    
    <div class="fortune-desc">
      <p>{{ fortune.overall.desc }}</p>
    </div>
    
    <div class="fortune-grid">
      <div class="fortune-item love">
        <div class="item-header">
          <span class="item-icon">💕</span>
          <span class="item-name">爱情运势</span>
          <span class="item-score">{{ fortune.love.score }}分</span>
        </div>
        <div class="item-keyword">{{ fortune.love.keyword }}</div>
        <p class="item-desc">{{ fortune.love.desc }}</p>
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: fortune.love.score + '%', background: '#ff6b9d' }"></div>
        </div>
      </div>
      
      <div class="fortune-item career">
        <div class="item-header">
          <span class="item-icon">💼</span>
          <span class="item-name">事业运势</span>
          <span class="item-score">{{ fortune.career.score }}分</span>
        </div>
        <div class="item-keyword">{{ fortune.career.keyword }}</div>
        <p class="item-desc">{{ fortune.career.desc }}</p>
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: fortune.career.score + '%', background: '#3498db' }"></div>
        </div>
      </div>
      
      <div class="fortune-item wealth">
        <div class="item-header">
          <span class="item-icon">💰</span>
          <span class="item-name">财富运势</span>
          <span class="item-score">{{ fortune.wealth.score }}分</span>
        </div>
        <div class="item-keyword">{{ fortune.wealth.keyword }}</div>
        <p class="item-desc">{{ fortune.wealth.desc }}</p>
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: fortune.wealth.score + '%', background: '#f1c40f' }"></div>
        </div>
      </div>
      
      <div class="fortune-item health">
        <div class="item-header">
          <span class="item-icon">💪</span>
          <span class="item-name">健康运势</span>
          <span class="item-score">{{ fortune.health.score }}分</span>
        </div>
        <div class="item-keyword">{{ fortune.health.keyword }}</div>
        <p class="item-desc">{{ fortune.health.desc }}</p>
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: fortune.health.score + '%', background: '#2ecc71' }"></div>
        </div>
      </div>
    </div>
    
    <div class="lucky-section">
      <h4>🍀 今日幸运指南</h4>
      <div class="lucky-grid">
        <div class="lucky-item">
          <span class="lucky-label">幸运数字</span>
          <div class="lucky-numbers">
            <span v-for="num in fortune.lucky.number" :key="num" class="lucky-number">{{ num }}</span>
          </div>
        </div>
        <div class="lucky-item">
          <span class="lucky-label">幸运颜色</span>
          <div class="lucky-color">
            <span class="color-dot" :style="{ background: fortune.lucky.color.hex }"></span>
            <span class="color-name">{{ fortune.lucky.color.name }}</span>
          </div>
        </div>
        <div class="lucky-item">
          <span class="lucky-label">幸运方位</span>
          <span class="lucky-value">{{ fortune.lucky.direction }}</span>
        </div>
        <div class="lucky-item">
          <span class="lucky-label">幸运物品</span>
          <span class="lucky-value">{{ fortune.lucky.item }}</span>
        </div>
      </div>
    </div>
    
    <div class="advice-section">
      <h4>💫 今日建议</h4>
      <p>{{ fortune.advice }}</p>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { getZodiacById } from '../data/zodiacData.js'

const props = defineProps({
  fortune: {
    type: Object,
    default: null
  }
})

const zodiacInfo = computed(() => {
  if (!props.fortune) return null
  return getZodiacById(props.fortune.zodiac)
})

const scoreClass = computed(() => {
  const score = props.fortune?.overall.score || 0
  if (score >= 80) return 'excellent'
  if (score >= 60) return 'good'
  if (score >= 40) return 'average'
  return 'poor'
})
</script>

<style scoped>
.fortune-display {
  animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.fortune-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.zodiac-info {
  display: flex;
  align-items: center;
  gap: 16px;
}

.zodiac-emoji {
  font-size: 3rem;
}

.zodiac-details h3 {
  font-size: 1.5rem;
  margin-bottom: 4px;
}

.fortune-date {
  color: rgba(255, 255, 255, 0.6);
  font-size: 0.9rem;
}

.overall-score {
  text-align: center;
}

.score-badge {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 12px 24px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.1);
}

.score-badge.excellent {
  background: linear-gradient(135deg, rgba(46, 204, 113, 0.3), rgba(39, 174, 96, 0.3));
  box-shadow: 0 4px 15px rgba(46, 204, 113, 0.3);
}

.score-badge.good {
  background: linear-gradient(135deg, rgba(52, 152, 219, 0.3), rgba(41, 128, 185, 0.3));
  box-shadow: 0 4px 15px rgba(52, 152, 219, 0.3);
}

.score-badge.average {
  background: linear-gradient(135deg, rgba(241, 196, 15, 0.3), rgba(243, 156, 18, 0.3));
  box-shadow: 0 4px 15px rgba(241, 196, 15, 0.3);
}

.score-badge.poor {
  background: linear-gradient(135deg, rgba(231, 76, 60, 0.3), rgba(192, 57, 43, 0.3));
  box-shadow: 0 4px 15px rgba(231, 76, 60, 0.3);
}

.score-number {
  font-size: 2rem;
  font-weight: bold;
}

.score-level {
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.8);
}

.fortune-desc {
  text-align: center;
  padding: 16px;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  margin-bottom: 24px;
}

.fortune-desc p {
  font-size: 1.1rem;
  color: rgba(255, 255, 255, 0.9);
}

.fortune-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}

.fortune-item {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  padding: 16px;
  transition: transform 0.3s ease;
}

.fortune-item:hover {
  transform: translateY(-3px);
}

.item-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.item-icon {
  font-size: 1.2rem;
}

.item-name {
  flex: 1;
  font-weight: 500;
}

.item-score {
  font-size: 1.1rem;
  font-weight: bold;
  color: #667eea;
}

.item-keyword {
  display: inline-block;
  padding: 4px 12px;
  background: rgba(102, 126, 234, 0.2);
  border-radius: 12px;
  font-size: 0.8rem;
  margin-bottom: 8px;
}

.item-desc {
  font-size: 0.9rem;
  color: rgba(255, 255, 255, 0.7);
  line-height: 1.5;
  margin-bottom: 12px;
}

.progress-bar {
  height: 6px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: 3px;
  transition: width 0.8s ease;
}

.lucky-section {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
}

.lucky-section h4 {
  margin-bottom: 16px;
  font-size: 1.1rem;
}

.lucky-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.lucky-item {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.lucky-label {
  font-size: 0.85rem;
  color: rgba(255, 255, 255, 0.6);
}

.lucky-numbers {
  display: flex;
  gap: 8px;
}

.lucky-number {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 50%;
  font-weight: bold;
}

.lucky-color {
  display: flex;
  align-items: center;
  gap: 8px;
}

.color-dot {
  width: 24px;
  height: 24px;
  border-radius: 50%;
}

.color-name {
  font-size: 0.95rem;
}

.lucky-value {
  font-size: 1rem;
  color: rgba(255, 255, 255, 0.9);
}

.advice-section {
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.2), rgba(118, 75, 162, 0.2));
  border-radius: 12px;
  padding: 20px;
  text-align: center;
}

.advice-section h4 {
  margin-bottom: 12px;
  font-size: 1.1rem;
}

.advice-section p {
  font-size: 1rem;
  color: rgba(255, 255, 255, 0.9);
  line-height: 1.6;
}

@media (max-width: 768px) {
  .fortune-grid {
    grid-template-columns: 1fr;
  }
  
  .lucky-grid {
    grid-template-columns: 1fr;
  }
  
  .zodiac-emoji {
    font-size: 2.5rem;
  }
  
  .zodiac-details h3 {
    font-size: 1.2rem;
  }
  
  .score-number {
    font-size: 1.5rem;
  }
}
</style>

<template>
  <div class="zodiac-selector">
    <h3 class="selector-title">{{ title }}</h3>
    <div class="zodiac-grid">
      <div
        v-for="sign in zodiacSigns"
        :key="sign.id"
        class="zodiac-item"
        :class="{ active: modelValue === sign.id }"
        @click="selectSign(sign.id)"
      >
        <span class="zodiac-emoji">{{ sign.emoji }}</span>
        <span class="zodiac-name">{{ sign.name }}</span>
        <span class="zodiac-date">{{ sign.date }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { zodiacSigns } from '../data/zodiacData.js'

const props = defineProps({
  modelValue: {
    type: String,
    default: ''
  },
  title: {
    type: String,
    default: '选择星座'
  }
})

const emit = defineEmits(['update:modelValue'])

const selectSign = (id) => {
  emit('update:modelValue', id)
}
</script>

<style scoped>
.zodiac-selector {
  margin-bottom: 24px;
}

.selector-title {
  text-align: center;
  margin-bottom: 16px;
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.9);
}

.zodiac-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 12px;
}

.zodiac-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px 8px;
  background: rgba(255, 255, 255, 0.05);
  border: 2px solid transparent;
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.zodiac-item:hover {
  background: rgba(255, 255, 255, 0.1);
  transform: translateY(-3px);
}

.zodiac-item.active {
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.3), rgba(118, 75, 162, 0.3));
  border-color: rgba(102, 126, 234, 0.8);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
}

.zodiac-emoji {
  font-size: 2rem;
  margin-bottom: 8px;
}

.zodiac-name {
  font-size: 0.95rem;
  font-weight: 500;
  margin-bottom: 4px;
}

.zodiac-date {
  font-size: 0.7rem;
  color: rgba(255, 255, 255, 0.5);
}

@media (max-width: 768px) {
  .zodiac-grid {
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
  }
  
  .zodiac-item {
    padding: 12px 4px;
  }
  
  .zodiac-emoji {
    font-size: 1.5rem;
  }
  
  .zodiac-name {
    font-size: 0.8rem;
  }
  
  .zodiac-date {
    font-size: 0.6rem;
  }
}
</style>

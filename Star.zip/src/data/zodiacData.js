export const zodiacSigns = [
  {
    id: 'aries',
    name: '白羊座',
    date: '3月21日 - 4月19日',
    element: '火象',
    symbol: '♈',
    emoji: '🐏',
    traits: {
      personality: ['热情', '冲动', '勇敢', '直率', '自信', '好胜'],
      strengths: ['充满活力', '行动力强', '敢于冒险', '领导能力', '真诚待人'],
      weaknesses: ['急躁', '冲动', '缺乏耐心', '自我中心', '容易放弃'],
      love: ['主动追求', '热情似火', '喜欢新鲜感', '需要自由空间'],
      career: ['创业者', '运动员', '军人', '销售', '领导者']
    },
    description: '白羊座是黄道十二宫的第一个星座，代表着新的开始。他们充满活力和热情，总是勇往直前。',
    loveProblems: [
      '容易因为冲动而伤害伴侣感情',
      '缺乏耐心，希望感情快速发展',
      '自我中心，有时忽略伴侣需求',
      '情绪波动大，容易发脾气',
      '需要学会控制脾气，多倾听伴侣'
    ]
  },
  {
    id: 'taurus',
    name: '金牛座',
    date: '4月20日 - 5月20日',
    element: '土象',
    symbol: '♉',
    emoji: '🐂',
    traits: {
      personality: ['稳重', '务实', '耐心', '固执', '享受', '忠诚'],
      strengths: ['可靠', '有耐心', '务实', '善于理财', '忠诚专一'],
      weaknesses: ['固执', '占有欲强', '不善变通', '过于物质', '慢热'],
      love: ['细水长流', '重视安全感', '忠诚专一', '喜欢稳定关系'],
      career: ['金融', '艺术', '美食', '建筑', '农业']
    },
    description: '金牛座追求稳定和安全感，他们务实可靠，对生活品质有很高的要求。',
    loveProblems: [
      '过于固执，不愿妥协',
      '占有欲强，让伴侣感到窒息',
      '不善表达情感，显得冷漠',
      '过于重视物质，忽略精神交流',
      '需要学会放手，给伴侣更多自由'
    ]
  },
  {
    id: 'gemini',
    name: '双子座',
    date: '5月21日 - 6月21日',
    element: '风象',
    symbol: '♊',
    emoji: '👯',
    traits: {
      personality: ['机智', '多变', '好奇', '善交际', '聪明', '活泼'],
      strengths: ['沟通能力强', '适应力强', '聪明机智', '幽默风趣', '博学多才'],
      weaknesses: ['善变', '表面化', '缺乏专注', '情绪化', '难以捉摸'],
      love: ['需要新鲜感', '重视沟通', '喜欢有趣的人', '需要精神共鸣'],
      career: ['媒体', '销售', '教育', '写作', '公关']
    },
    description: '双子座拥有双重性格，聪明机智，善于沟通，对世界充满好奇心。',
    loveProblems: [
      '情绪多变，让伴侣难以适应',
      '表面化的交流，缺乏深度',
      '容易分心，不够专注',
      '害怕承诺，逃避责任',
      '需要学会稳定情绪，深入交流'
    ]
  },
  {
    id: 'cancer',
    name: '巨蟹座',
    date: '6月22日 - 7月22日',
    element: '水象',
    symbol: '♋',
    emoji: '🦀',
    traits: {
      personality: ['敏感', '顾家', '温柔', '情绪化', '保护欲强', '念旧'],
      strengths: ['体贴入微', '忠诚', '有同情心', '直觉敏锐', '善于照顾人'],
      weaknesses: ['情绪化', '过于敏感', '缺乏安全感', '念旧', '容易受伤'],
      love: ['渴望安全感', '重视家庭', '温柔体贴', '需要被呵护'],
      career: ['护理', '教育', '餐饮', '房地产', '心理咨询']
    },
    description: '巨蟹座是最顾家的星座，他们温柔体贴，对家人和朋友非常忠诚。',
    loveProblems: [
      '过于敏感，容易胡思乱想',
      '情绪化严重，影响关系',
      '缺乏安全感，需要不断确认',
      '过度保护，让伴侣感到压力',
      '需要学会独立，建立自信'
    ]
  },
  {
    id: 'leo',
    name: '狮子座',
    date: '7月23日 - 8月22日',
    element: '火象',
    symbol: '♌',
    emoji: '🦁',
    traits: {
      personality: ['自信', '慷慨', '领导力强', '爱面子', '热情', '戏剧化'],
      strengths: ['自信大方', '慷慨', '领导能力', '创造力', '忠诚'],
      weaknesses: ['自负', '爱面子', '控制欲强', '固执', '需要被关注'],
      love: ['热情浪漫', '喜欢被崇拜', '忠诚专一', '需要被认可'],
      career: ['管理', '演艺', '政治', '创业', '设计']
    },
    description: '狮子座是天生的领导者，他们自信大方，喜欢成为焦点，慷慨而热情。',
    loveProblems: [
      '过于自负，忽视伴侣感受',
      '爱面子，不愿低头认错',
      '控制欲强，希望主导关系',
      '需要不断被关注和赞美',
      '需要学会谦逊，尊重伴侣'
    ]
  },
  {
    id: 'virgo',
    name: '处女座',
    date: '8月23日 - 9月22日',
    element: '土象',
    symbol: '♍',
    emoji: '👧',
    traits: {
      personality: ['完美主义', '细心', '务实', '挑剔', '谦虚', '分析力强'],
      strengths: ['细心周到', '分析能力强', '务实', '勤奋', '乐于助人'],
      weaknesses: ['挑剔', '过于完美主义', '焦虑', '吹毛求疵', '自我批评'],
      love: ['慢热', '重视细节', '用行动表达爱', '追求完美关系'],
      career: ['医疗', '编辑', '研究', '会计', '质检']
    },
    description: '处女座追求完美，细心周到，他们善于分析，对工作和生活都有很高的标准。',
    loveProblems: [
      '过于挑剔，让伴侣感到压力',
      '完美主义导致焦虑',
      '不善表达情感，显得冷漠',
      '过度关注细节，忽略大局',
      '需要学会接受不完美，放松心态'
    ]
  },
  {
    id: 'libra',
    name: '天秤座',
    date: '9月23日 - 10月23日',
    element: '风象',
    symbol: '♎',
    emoji: '⚖️',
    traits: {
      personality: ['优雅', '追求平衡', '犹豫不决', '社交能力强', '浪漫', '公正'],
      strengths: ['外交能力强', '优雅', '公正', '善于协调', '审美能力强'],
      weaknesses: ['犹豫不决', '逃避冲突', '过于在意他人看法', '优柔寡断', '表面化'],
      love: ['追求和谐', '浪漫', '重视平等', '需要陪伴'],
      career: ['法律', '艺术', '外交', '时尚', '公关']
    },
    description: '天秤座追求和谐与平衡，他们优雅迷人，善于社交，重视公平正义。',
    loveProblems: [
      '犹豫不决，难以做决定',
      '逃避冲突，问题积累',
      '过于在意他人看法',
      '优柔寡断，让伴侣不安',
      '需要学会果断，直面问题'
    ]
  },
  {
    id: 'scorpio',
    name: '天蝎座',
    date: '10月24日 - 11月22日',
    element: '水象',
    symbol: '♏',
    emoji: '🦂',
    traits: {
      personality: ['神秘', '深情', '占有欲强', '洞察力强', '执着', '极端'],
      strengths: ['洞察力强', '忠诚', '有毅力', '直觉敏锐', '充满魅力'],
      weaknesses: ['占有欲强', '报复心重', '多疑', '控制欲强', '极端'],
      love: ['深情专一', '占有欲强', '追求灵魂伴侣', '爱恨分明'],
      career: ['侦探', '心理学', '金融', '研究', '医学']
    },
    description: '天蝎座神秘而深情，他们洞察力强，爱恨分明，对感情极其专一。',
    loveProblems: [
      '占有欲和控制欲过强',
      '多疑，缺乏信任',
      '爱恨极端，难以释怀',
      '报复心理，伤害关系',
      '需要学会信任，放下执念'
    ]
  },
  {
    id: 'sagittarius',
    name: '射手座',
    date: '11月23日 - 12月21日',
    element: '火象',
    symbol: '♐',
    emoji: '🏹',
    traits: {
      personality: ['自由', '乐观', '冒险', '直率', '哲学', '不拘小节'],
      strengths: ['乐观开朗', '诚实', '热爱自由', '冒险精神', '哲学思维'],
      weaknesses: ['不负责任', '过于直率', '缺乏耐心', '承诺恐惧', '粗心'],
      love: ['需要自由', '喜欢冒险', '诚实直接', '不喜欢束缚'],
      career: ['旅游', '教育', '出版', '外交', '体育']
    },
    description: '射手座热爱自由，乐观开朗，他们喜欢冒险和探索，诚实而直率。',
    loveProblems: [
      '害怕承诺，逃避责任',
      '过于追求自由，忽略伴侣',
      '说话太直，容易伤人',
      '缺乏耐心，容易厌倦',
      '需要学会平衡自由与责任'
    ]
  },
  {
    id: 'capricorn',
    name: '摩羯座',
    date: '12月22日 - 1月19日',
    element: '土象',
    symbol: '♑',
    emoji: '🐐',
    traits: {
      personality: ['务实', '有野心', '自律', '保守', '责任感强', '传统'],
      strengths: ['有责任感', '自律', '务实', '有野心', '可靠', '有耐心'],
      weaknesses: ['工作狂', '过于严肃', '悲观', '不善表达情感', '固执'],
      love: ['慢热', '重视承诺', '用实际行动表达', '追求稳定'],
      career: ['管理', '金融', '工程', '政府', '企业高管']
    },
    description: '摩羯座务实而有野心，他们自律严谨，对事业和目标有着坚定的追求。',
    loveProblems: [
      '工作狂，忽略感情生活',
      '过于严肃，缺乏情趣',
      '不善表达情感，显得冷漠',
      '悲观，容易看到问题',
      '需要学会放松，表达爱意'
    ]
  },
  {
    id: 'aquarius',
    name: '水瓶座',
    date: '1月20日 - 2月18日',
    element: '风象',
    symbol: '♒',
    emoji: '🏺',
    traits: {
      personality: ['独立', '创新', '理性', '人道主义', '独特', '友善'],
      strengths: ['创新思维', '独立', '理性', '人道主义', '友善', '前卫'],
      weaknesses: ['疏离', '固执', '情感冷漠', '叛逆', '难以捉摸'],
      love: ['需要独立空间', '重视友谊', '理性对待感情', '追求精神契合'],
      career: ['科技', '社会服务', '艺术', '研究', '发明']
    },
    description: '水瓶座独立创新，他们思维前卫，重视友谊，追求独特的生活方式。',
    loveProblems: [
      '过于理性，缺乏情感交流',
      '需要太多独立空间',
      '情感疏离，让伴侣感到冷漠',
      '固执己见，不愿妥协',
      '需要学会表达情感，增加亲密感'
    ]
  },
  {
    id: 'pisces',
    name: '双鱼座',
    date: '2月19日 - 3月20日',
    element: '水象',
    symbol: '♓',
    emoji: '🐟',
    traits: {
      personality: ['浪漫', '敏感', '富有同情心', '梦幻', '艺术气质', '直觉强'],
      strengths: ['富有同情心', '艺术天赋', '直觉强', '温柔', '包容', '浪漫'],
      weaknesses: ['逃避现实', '过于敏感', '优柔寡断', '容易受骗', '缺乏界限'],
      love: ['浪漫多情', '无私奉献', '追求灵魂伴侣', '容易陷入幻想'],
      career: ['艺术', '音乐', '医疗', '慈善', '心理咨询']
    },
    description: '双鱼座浪漫多情，富有同情心，他们直觉敏锐，有着丰富的想象力和艺术天赋。',
    loveProblems: [
      '过于理想化，忽视现实',
      '容易陷入幻想，看不清真相',
      '过于敏感，容易受伤',
      '缺乏界限，容易失去自我',
      '需要学会面对现实，建立界限'
    ]
  }
]

export const compatibilityMatrix = {
  aries: {
    aries: { score: 70, desc: '两个火象星座碰撞，充满激情但容易冲突' },
    taurus: { score: 60, desc: '白羊的冲动与金牛的稳重需要磨合' },
    gemini: { score: 85, desc: '充满活力和乐趣的组合，互相激发' },
    cancer: { score: 55, desc: '白羊的直接可能伤害敏感的巨蟹' },
    leo: { score: 90, desc: '火象星座的完美结合，充满激情和创造力' },
    virgo: { score: 50, desc: '性格差异大，需要大量磨合' },
    libra: { score: 80, desc: '互补的组合，互相吸引' },
    scorpio: { score: 65, desc: '强烈的吸引力，但控制欲可能冲突' },
    sagittarius: { score: 95, desc: '最佳组合之一，共同热爱冒险和自由' },
    capricorn: { score: 45, desc: '生活节奏和价值观差异较大' },
    aquarius: { score: 75, desc: '互相欣赏对方的独特性' },
    pisces: { score: 60, desc: '白羊需要学会温柔对待敏感的双鱼' }
  },
  taurus: {
    aries: { score: 60, desc: '节奏不同，需要互相理解' },
    taurus: { score: 80, desc: '稳定但可能缺乏激情' },
    gemini: { score: 50, desc: '金牛需要安全感，双子需要自由' },
    cancer: { score: 90, desc: '都非常重视家庭，完美组合' },
    leo: { score: 55, desc: '价值观和生活方式差异大' },
    virgo: { score: 95, desc: '土象星座的完美配对，务实稳定' },
    libra: { score: 70, desc: '都受金星守护，有共同爱好' },
    scorpio: { score: 85, desc: '对宫星座，强烈的吸引力' },
    sagittarius: { score: 45, desc: '生活方式和价值观冲突' },
    capricorn: { score: 95, desc: '事业和生活的完美伙伴' },
    aquarius: { score: 40, desc: '传统与创新的冲突' },
    pisces: { score: 80, desc: '温柔体贴的组合，互相滋养' }
  },
  gemini: {
    aries: { score: 85, desc: '充满活力和刺激的组合' },
    taurus: { score: 50, desc: '节奏和需求的差异' },
    gemini: { score: 75, desc: '有趣的交流，但可能缺乏深度' },
    cancer: { score: 55, desc: '双子需要自由，巨蟹需要安全感' },
    leo: { score: 80, desc: '互相欣赏，充满乐趣' },
    virgo: { score: 60, desc: '都受水星守护，但表达方式不同' },
    libra: { score: 90, desc: '风象星座的完美组合，智力契合' },
    scorpio: { score: 50, desc: '深度和表面的冲突' },
    sagittarius: { score: 85, desc: '对宫星座，互相学习成长' },
    capricorn: { score: 45, desc: '生活节奏和目标不同' },
    aquarius: { score: 90, desc: '思想上的最佳拍档' },
    pisces: { score: 65, desc: '理性与感性的碰撞' }
  },
  cancer: {
    aries: { score: 55, desc: '需要互相理解和包容' },
    taurus: { score: 90, desc: '温暖安全的家庭组合' },
    gemini: { score: 55, desc: '情感需求不匹配' },
    cancer: { score: 80, desc: '深刻的情感连接，但可能过于情绪化' },
    leo: { score: 60, desc: '巨蟹需要关注，狮子需要崇拜' },
    virgo: { score: 85, desc: '互相照顾，温馨的组合' },
    libra: { score: 65, desc: '巨蟹的情绪化让天秤困扰' },
    scorpio: { score: 95, desc: '水象星座的深度连接' },
    sagittarius: { score: 45, desc: '生活方式差异巨大' },
    capricorn: { score: 85, desc: '对宫星座，互补的组合' },
    aquarius: { score: 40, desc: '情感需求完全相反' },
    pisces: { score: 90, desc: '浪漫多情的水象组合' }
  },
  leo: {
    aries: { score: 90, desc: '火象星座的热情碰撞' },
    taurus: { score: 55, desc: '固执的碰撞，需要妥协' },
    gemini: { score: 80, desc: '充满乐趣和刺激' },
    cancer: { score: 60, desc: '需要平衡关注点和安全感' },
    leo: { score: 75, desc: '两个王者，需要学会分享舞台' },
    virgo: { score: 50, desc: '表达爱的方式不同' },
    libra: { score: 85, desc: '互相欣赏，优雅的组合' },
    scorpio: { score: 70, desc: '强烈的吸引力，权力斗争' },
    sagittarius: { score: 90, desc: '热爱冒险的火象组合' },
    capricorn: { score: 50, desc: '不同的价值观和生活方式' },
    aquarius: { score: 80, desc: '对宫星座，互相吸引' },
    pisces: { score: 65, desc: '狮子需要学会温柔' }
  },
  virgo: {
    aries: { score: 50, desc: '节奏和方式的差异' },
    taurus: { score: 95, desc: '土象星座的完美配对' },
    gemini: { score: 60, desc: '水星守护，但风格不同' },
    cancer: { score: 85, desc: '互相照顾，温馨稳定' },
    leo: { score: 50, desc: '需要互相适应' },
    virgo: { score: 80, desc: '完美主义的双倍，可能过于挑剔' },
    libra: { score: 70, desc: '都追求和谐，但方式不同' },
    scorpio: { score: 85, desc: '深度和细节的结合' },
    sagittarius: { score: 45, desc: '生活方式完全不同' },
    capricorn: { score: 95, desc: '事业和生活的完美伙伴' },
    aquarius: { score: 55, desc: '传统与创新的差异' },
    pisces: { score: 80, desc: '对宫星座，互相补充' }
  },
  libra: {
    aries: { score: 80, desc: '对宫星座，强烈的吸引力' },
    taurus: { score: 70, desc: '共同的美学追求' },
    gemini: { score: 90, desc: '风象星座的智力游戏' },
    cancer: { score: 65, desc: '需要平衡情感和理性' },
    leo: { score: 85, desc: '优雅和魅力的组合' },
    virgo: { score: 70, desc: '都追求完美，但标准不同' },
    libra: { score: 75, desc: '和谐但可能优柔寡断' },
    scorpio: { score: 60, desc: '深度和表面的张力' },
    sagittarius: { score: 80, desc: '热爱社交和冒险' },
    capricorn: { score: 55, desc: '不同的优先级' },
    aquarius: { score: 90, desc: '理想主义者的联盟' },
    pisces: { score: 75, desc: '浪漫和艺术的结合' }
  },
  scorpio: {
    aries: { score: 65, desc: '强烈的激情，权力斗争' },
    taurus: { score: 85, desc: '对宫星座，深刻的连接' },
    gemini: { score: 50, desc: '深度和变化的冲突' },
    cancer: { score: 95, desc: '水象星座的灵魂伴侣' },
    leo: { score: 70, desc: '两个强势星座的碰撞' },
    virgo: { score: 85, desc: '深度和细节的完美组合' },
    libra: { score: 60, desc: '情感表达方式的差异' },
    scorpio: { score: 80, desc: '深刻的理解，但可能过于激烈' },
    sagittarius: { score: 55, desc: '自由与控制的冲突' },
    capricorn: { score: 90, desc: '野心和深度的结合' },
    aquarius: { score: 50, desc: '情感需求的巨大差异' },
    pisces: { score: 95, desc: '水象星座的浪漫组合' }
  },
  sagittarius: {
    aries: { score: 95, desc: '火象星座的冒险之旅' },
    taurus: { score: 45, desc: '自由与稳定的冲突' },
    gemini: { score: 85, desc: '对宫星座，互相启发' },
    cancer: { score: 45, desc: '生活方式完全不同' },
    leo: { score: 90, desc: '热情和乐观的组合' },
    virgo: { score: 45, desc: '细节和大局的冲突' },
    libra: { score: 80, desc: '社交和乐观的组合' },
    scorpio: { score: 55, desc: '自由与深度的张力' },
    sagittarius: { score: 80, desc: '双倍的冒险，但可能缺乏稳定' },
    capricorn: { score: 50, desc: '目标和方式的差异' },
    aquarius: { score: 85, desc: '自由和理想的伙伴' },
    pisces: { score: 70, desc: '梦想和哲学的结合' }
  },
  capricorn: {
    aries: { score: 45, desc: '节奏和目标的差异' },
    taurus: { score: 95, desc: '土象星座的稳定联盟' },
    gemini: { score: 45, desc: '严肃与轻松的冲突' },
    cancer: { score: 85, desc: '对宫星座，互补的组合' },
    leo: { score: 50, desc: '不同的价值观' },
    virgo: { score: 95, desc: '完美的事业和生活伙伴' },
    libra: { score: 55, desc: '工作和社会需求的差异' },
    scorpio: { score: 90, desc: '野心和深度的结合' },
    sagittarius: { score: 50, desc: '责任和自由的冲突' },
    capricorn: { score: 85, desc: '稳定但可能过于严肃' },
    aquarius: { score: 55, desc: '传统与创新的张力' },
    pisces: { score: 80, desc: '现实和梦想的平衡' }
  },
  aquarius: {
    aries: { score: 75, desc: '独立和创新的组合' },
    taurus: { score: 40, desc: '传统与前卫的冲突' },
    gemini: { score: 90, desc: '思想的最佳拍档' },
    cancer: { score: 40, desc: '情感需求完全相反' },
    leo: { score: 80, desc: '对宫星座，互相学习' },
    virgo: { score: 55, desc: '服务和创新的差异' },
    libra: { score: 90, desc: '风象星座的理想联盟' },
    scorpio: { score: 50, desc: '独立与控制的冲突' },
    sagittarius: { score: 85, desc: '自由和探索的伙伴' },
    capricorn: { score: 55, desc: '未来和传统的张力' },
    aquarius: { score: 80, desc: '独特的组合，但可能疏离' },
    pisces: { score: 65, desc: '理性和感性的碰撞' }
  },
  pisces: {
    aries: { score: 60, desc: '需要学会互相理解' },
    taurus: { score: 80, desc: '温柔和稳定的组合' },
    gemini: { score: 65, desc: '感性和理性的交流' },
    cancer: { score: 90, desc: '水象星座的深情连接' },
    leo: { score: 65, desc: '需要平衡关注和独立' },
    virgo: { score: 80, desc: '对宫星座，互相补充' },
    libra: { score: 75, desc: '浪漫和艺术的结合' },
    scorpio: { score: 95, desc: '水象星座的强烈连接' },
    sagittarius: { score: 70, desc: '梦想和哲学的交流' },
    capricorn: { score: 80, desc: '梦想和现实的平衡' },
    aquarius: { score: 65, desc: '理想和人文的结合' },
    pisces: { score: 85, desc: '双倍的浪漫，但可能脱离现实' }
  }
}

export function getZodiacById(id) {
  return zodiacSigns.find(sign => sign.id === id)
}

export function getCompatibility(sign1, sign2) {
  if (!sign1 || !sign2) return null
  return compatibilityMatrix[sign1]?.[sign2] || null
}

export function getFortuneKeywords() {
  return {
    overall: ['大吉', '吉', '平', '凶', '大凶'],
    love: ['桃花运旺', '稳定发展', '需要沟通', '小心误会', '独处为佳'],
    career: ['升职加薪', '贵人相助', '稳扎稳打', '谨慎决策', '避免冲突'],
    wealth: ['财源广进', '小有收获', '收支平衡', '控制开支', '避免投资'],
    health: ['精力充沛', '状态良好', '注意休息', '预防小病', '调养身体']
  }
}
